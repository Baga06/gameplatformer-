package org.example.platformergame;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * Контроллер для окна статистики игрока
 */
public class StatisticsController {

    @FXML
    private Label playerNameLabel;

    @FXML
    private Label level1DeathsLabel;

    @FXML
    private Label level1TimeLabel;

    @FXML
    private Label level1RecordLabel;

    @FXML
    private Label level2DeathsLabel;

    @FXML
    private Label level2TimeLabel;

    @FXML
    private Label level2RecordLabel;

    @FXML
    private Label level3DeathsLabel;

    @FXML
    private Label level3TimeLabel;

    @FXML
    private Label level3RecordLabel;

    @FXML
    private Label totalDeathsLabel;

    @FXML
    private Label totalTimeLabel;

    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
        loadStatistics();
    }

    /**
     * Загрузить статистику из базы данных
     */
    private void loadStatistics() {
        try {
            DatabaseManager db = DatabaseManager.getInstance();

            int playerId = db.createOrGetPlayer("Player1");
            String playerName = db.getPlayerName(playerId);

            playerNameLabel.setText("Player name: " + playerName);

            // Загружаем общую статистику
            DatabaseManager.PlayerProgress progress = db.loadProgress(playerId);
            if (progress != null) {
                totalDeathsLabel.setText("Total Deaths:" + progress.totalDeaths);
                totalTimeLabel.setText(String.format("Best Time: %.1f сек", progress.bestTime));
            } else {
                totalDeathsLabel.setText("Total Deaths: 0");
                totalTimeLabel.setText("Best Time: -");
            }

            // Загружаем статистику по уровням
            loadLevelStatistics(playerName, 1);
            loadLevelStatistics(playerName, 2);
            loadLevelStatistics(playerName, 3);

        } catch (Exception e) {
            System.err.println("❌ Ошибка при загрузке статистики: " + e.getMessage());
            playerNameLabel.setText("Ошибка загрузки данных");
        }
    }

    /**
     * Загрузить статистику для конкретного уровня
     */
    private void loadLevelStatistics(String playerName, int level) {
        DatabaseManager db = DatabaseManager.getInstance();
        DatabaseManager.LevelStatistics stats = db.getLevelStatistics(playerName, level);

        Label deathsLabel = getLevelDeathsLabel(level);
        Label timeLabel = getLevelTimeLabel(level);
        Label recordLabel = getLevelRecordLabel(level);

        if (stats != null && stats.attempts > 0) {
            deathsLabel.setText("Attempts: " + stats.attempts);
            timeLabel.setText(String.format("Best Time: %.1f сек", stats.bestTime));
            recordLabel.setText(String.format("Record: %.1f сек (%.0f очков)",
                    stats.topTime, stats.topScore));
        } else {
            deathsLabel.setText("Attempts: 0");
            timeLabel.setText("Best Time: -");
            recordLabel.setText("Record: -");
        }
    }

    /**
     * Получить Label для смертей уровня
     */
    private Label getLevelDeathsLabel(int level) {
        switch (level) {
            case 1: return level1DeathsLabel;
            case 2: return level2DeathsLabel;
            case 3: return level3DeathsLabel;
            default: return null;
        }
    }

    /**
     * Получить Label для времени уровня
     */
    private Label getLevelTimeLabel(int level) {
        switch (level) {
            case 1: return level1TimeLabel;
            case 2: return level2TimeLabel;
            case 3: return level3TimeLabel;
            default: return null;
        }
    }

    /**
     * Получить Label для рекорда уровня
     */
    private Label getLevelRecordLabel(int level) {
        switch (level) {
            case 1: return level1RecordLabel;
            case 2: return level2RecordLabel;
            case 3: return level3RecordLabel;
            default: return null;
        }
    }


    @FXML
    private void onBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
            Parent root = loader.load();
            MenuController controller = loader.getController();
            controller.setStage(stage);
            stage.setScene(new Scene(root, 900, 600));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Кнопка "Сбросить статистику"
     */
    @FXML
    private void onResetStats() {
        try {
            DatabaseManager db = DatabaseManager.getInstance();
            db.resetStatistics("Player1");
            loadStatistics(); // Перезагружаем данные
            System.out.println("✅ Статистика сброшена!");
        } catch (Exception e) {
            System.err.println("❌ Ошибка при сбросе статистики: " + e.getMessage());
        }
    }
}