package org.example.platformergame;

public class Coin {
    private double x, y;
    private final double size;
    private boolean collected = false;

    public Coin(double x, double y, double size) {
        this.x = x;
        this.y = y;
        this.size = size;
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public double getSize() { return size; }
    public boolean isCollected() { return collected; }

    public void collect() {
        collected = true;
    }

    public boolean intersects(Player player) {
        double px = player.getX();
        double py = player.getY();
        double pw = player.getWidth();
        double ph = player.getHeight();

        return px < x + size &&
                px + pw > x &&
                py < y + size &&
                py + ph > y;
    }
}