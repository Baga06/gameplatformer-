package org.example.platformergame;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.*;

public class Gamecontroller {

    @FXML
    private Pane gamePane;

    @FXML
    private Label scoreLabel;

    private Player player;
    private Rectangle playerView;

    private final List<Platform> platforms = new ArrayList<>();
    private final Map<KeyCode, Boolean> keys = new HashMap<>();

    private AnimationTimer gameLoop;
    private int score = 0;

    @FXML
    public void initialize() {
        setupPlayer();
        setupPlatforms();

        gamePane.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                newScene.setOnKeyPressed(e -> keys.put(e.getCode(), true));
                newScene.setOnKeyReleased(e -> keys.put(e.getCode(), false));
            }
        });

        startLoop();
    }

    private void setupPlayer() {
        player = new Player(50, 400, 36, 48);
        playerView = new Rectangle(player.getWidth(), player.getHeight(), Color.DODGERBLUE);
        gamePane.getChildren().add(playerView);
    }

    private void setupPlatforms() {
        platforms.add(new Platform(0, 520, 900, 80));
        platforms.add(new Platform(150, 420, 140, 16));
        platforms.add(new Platform(360, 360, 140, 16));
        platforms.add(new Platform(580, 300, 120, 16));

        for (Platform p : platforms) {
            Rectangle r = new Rectangle(p.getWidth(), p.getHeight(), Color.DARKGRAY);
            r.setTranslateX(p.getX());
            r.setTranslateY(p.getY());
            gamePane.getChildren().add(r);
        }
    }
    @FXML
    private void onReset(javafx.event.ActionEvent event) {
        // например, сброс позиции игрока
        player.setX(50);
        player.setY(400);
        score = 0;
        scoreLabel.setText("Score: " + score);
    }

    private void startLoop() {
        gameLoop = new AnimationTimer() {
            private long last = 0;

            @Override
            public void handle(long now) {
                if (last == 0) last = now;
                double delta = (now - last) / 1_000_000_000.0;

                update(delta);
                render();

                last = now;
            }
        };
        gameLoop.start();
    }

    private void update(double dt) {
        player.savePrevY();

        // управление
        if (isPressed(KeyCode.A) || isPressed(KeyCode.LEFT)) {
            player.moveX(-200 * dt);
        }
        if (isPressed(KeyCode.D) || isPressed(KeyCode.RIGHT)) {
            player.moveX(200 * dt);
        }
        if ((isPressed(KeyCode.SPACE) || isPressed(KeyCode.W) || isPressed(KeyCode.UP))
                && player.isOnGround()) {
            player.jump();
        }

        // физика
        player.applyGravity(dt);
        player.setOnGround(false);

        // ТОЛЬКО вертикальные коллизии
        for (Platform p : platforms) {
            if (player.intersects(p)) {
                double prevBottom = player.getPrevY() + player.getHeight();
                double currBottom = player.getY() + player.getHeight();

                if (prevBottom <= p.getY() && currBottom >= p.getY()) {
                    player.landOn(p.getY() - player.getHeight());
                }
            }
        }

        // границы
        if (player.getX() < 0) player.setX(0);
        if (player.getX() + player.getWidth() > 900) {
            player.setX(900 - player.getWidth());
        }

        scoreLabel.setText("Score: " + score);
    }

    private void render() {
        playerView.setTranslateX(player.getX());
        playerView.setTranslateY(player.getY());
    }

    private boolean isPressed(KeyCode key) {
        return keys.getOrDefault(key, false);
    }
}
