package org.example.platformergame;

public class Enemy {
    private double x, y;
    private final double width, height;
    private double speed;
    private double minX, maxX;
    private boolean movingRight = true;

    public Enemy(double x, double y, double width, double height, double minX, double maxX, double speed) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.minX = minX;
        this.maxX = maxX;
        this.speed = speed;
    }

    public void update(double dt) {
        if (movingRight) {
            x += speed * dt;
            if (x >= maxX) {
                x = maxX;
                movingRight = false;
            }
        } else {
            x -= speed * dt;
            if (x <= minX) {
                x = minX;
                movingRight = true;
            }
        }
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public double getWidth() { return width; }
    public double getHeight() { return height; }
    public boolean isMovingRight() { return movingRight; }

    public boolean intersects(Player player) {
        double px = player.getX();
        double py = player.getY();
        double pw = player.getWidth();
        double ph = player.getHeight();

        return px < x + width &&
                px + pw > x &&
                py < y + height &&
                py + ph > y;
    }
}