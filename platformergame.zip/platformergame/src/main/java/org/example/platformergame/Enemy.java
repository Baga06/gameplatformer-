package org.example.platformergame;

public class Enemy {
    private double x, y;
    private final double width, height;
    private double speed;
    private double minX, maxX;
    private boolean movingRight = true;
    private double velocityY = 0; // Вертикальная скорость для гравитации
    private boolean onGround = false;

    // AI параметры
    private double visionRange = 400; // Дальность видимости
    private boolean chasingPlayer = false;
    private double normalSpeed;
    private double chaseSpeed;

    private static final double GRAVITY = 1200; // Гравитация как у игрока

    public Enemy(double x, double y, double width, double height, double minX, double maxX, double speed) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.minX = minX;
        this.maxX = maxX;
        this.normalSpeed = speed;
        this.chaseSpeed = speed * 1.5;
        this.speed = normalSpeed;
    }

    public void update(double dt, Player player) {
        // Применяем гравитацию
        velocityY += GRAVITY * dt;
        y += velocityY * dt;

        // Проверяем видит ли враг игрока (СТРОГО по горизонтали)
        double distanceToPlayer = Math.abs(player.getX() - x);
        double heightDifference = Math.abs(player.getY() - y);

        // Враг видит только если на ОДНОЙ ВЫСОТЕ (±50px максимум)
        if (distanceToPlayer < visionRange && heightDifference < 50) {
            // Режим преследования!
            chasingPlayer = true;
            speed = chaseSpeed;

            // Двигаемся к игроку БЕЗ ОГРАНИЧЕНИЙ
            if (player.getX() > x) {
                movingRight = true;
                x += speed * dt;
            } else {
                movingRight = false;
                x -= speed * dt;
            }

            // НЕТ ОГРАНИЧЕНИЙ при преследовании!

        } else {
            // Обычное патрулирование
            chasingPlayer = false;
            speed = normalSpeed;

            // Возвращаемся в зону патруля если вышли
            if (x < minX) {
                x += speed * dt;
                movingRight = true;
            } else if (x > maxX) {
                x -= speed * dt;
                movingRight = false;
            } else {
                // Нормальное патрулирование
                if (movingRight) {
                    x += speed * dt;
                    if (x >= maxX) {
                        x = maxX;
                        movingRight = false;
                    }
                } else {
                    x -= speed * dt;
                    if (x <= minX) {
                        x = minX;
                        movingRight = true;
                    }
                }
            }
        }
    }

    public void applyPlatformCollision(double platformTop) {
        // Враг приземляется на платформу
        y = platformTop - height;
        velocityY = 0;
        onGround = true;
    }

    public void setOnGround(boolean onGround) {
        this.onGround = onGround;
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public double getWidth() { return width; }
    public double getHeight() { return height; }
    public double getVelocityY() { return velocityY; }
    public boolean isMovingRight() { return movingRight; }
    public boolean isChasingPlayer() { return chasingPlayer; }

    public boolean intersects(Player player) {
        double px = player.getX();
        double py = player.getY();
        double pw = player.getWidth();
        double ph = player.getHeight();

        return px < x + width &&
                px + pw > x &&
                py < y + height &&
                py + ph > y;
    }

    public boolean intersectsPlatform(Platform p) {
        return x < p.getX() + p.getWidth() &&
                x + width > p.getX() &&
                y < p.getY() + p.getHeight() &&
                y + height > p.getY();
    }
}