package org.example.platformergame;

import javafx.scene.paint.Color;

/**
 * Движущаяся платформа - двигается по заданному пути
 */
public class MovingPlatform extends Platform {

    public enum Direction {
        HORIZONTAL,
        VERTICAL
    }

    private Direction direction;
    private double minPos;
    private double maxPos;
    private double speed;
    private boolean movingForward = true;

    private double startX;
    private double startY;

    private double currentVelocityX = 0;
    private double currentVelocityY = 0;

    public MovingPlatform(double x, double y, double width, double height,
                          Direction direction, double minPos, double maxPos, double speed) {
        super(x, y, width, height, Color.CYAN);
        this.direction = direction;
        this.minPos = minPos;
        this.maxPos = maxPos;
        this.speed = speed;
        this.startX = x;
        this.startY = y;
    }

    public void update(double dt) {
        double oldX = getX();
        double oldY = getY();

        if (direction == Direction.HORIZONTAL) {
            if (movingForward) {
                setX(getX() + speed * dt);
                if (getX() >= maxPos) {
                    setX(maxPos);
                    movingForward = false;
                }
            } else {
                setX(getX() - speed * dt);
                if (getX() <= minPos) {
                    setX(minPos);
                    movingForward = true;
                }
            }

            currentVelocityX = (getX() - oldX) / dt;
            currentVelocityY = 0;

        } else {
            if (movingForward) {
                setY(getY() + speed * dt);
                if (getY() >= maxPos) {
                    setY(maxPos);
                    movingForward = false;
                }
            } else {
                setY(getY() - speed * dt);
                if (getY() <= minPos) {
                    setY(minPos);
                    movingForward = true;
                }
            }

            currentVelocityX = 0;
            currentVelocityY = (getY() - oldY) / dt;
        }
    }

    public double getVelocityX() {
        return currentVelocityX;
    }

    public double getVelocityY() {
        return currentVelocityY;
    }

    public Direction getDirection() {
        return direction;
    }
}