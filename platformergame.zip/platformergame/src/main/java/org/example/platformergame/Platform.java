package org.example.platformergame;

import javafx.scene.paint.Color;

public class Platform {
    private double x, y;
    private final double width, height;
    private Color color;

    public Platform(double x, double y, double width, double height) {
        this(x, y, width, height, Color.DARKGRAY);
    }

    public Platform(double x, double y, double width, double height, Color color) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.color = color;
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public double getWidth() { return width; }
    public double getHeight() { return height; }
    public Color getColor() { return color; }

    // НОВЫЕ МЕТОДЫ для специальных платформ
    public void setX(double x) { this.x = x; }
    public void setY(double y) { this.y = y; }
    public void setColor(Color color) { this.color = color; }
}