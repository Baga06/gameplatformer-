package org.example.platformergame;

import javafx.scene.paint.Color;

/**
 * Падающая платформа - исчезает через секунду после наступления
 */
public class FallingPlatform extends Platform {

    private boolean activated = false;  // Игрок наступил?
    private double fallTimer = 0;       // Таймер падения
    private static final double FALL_DELAY = 1.0; // Секунда до падения
    private boolean falling = false;    // Платформа падает?
    private double fallSpeed = 0;       // Скорость падения

    public FallingPlatform(double x, double y, double width, double height) {
        super(x, y, width, height, Color.ORANGE);
    }

    /**
     * Активировать платформу (игрок наступил)
     */
    public void activate() {
        if (!activated && !falling) {
            activated = true;
            fallTimer = 0;
        }
    }

    /**
     * Обновить состояние платформы
     */
    public void update(double dt) {
        if (activated && !falling) {
            fallTimer += dt;

            // Через секунду начинаем падать
            if (fallTimer >= FALL_DELAY) {
                falling = true;
            }
        }

        if (falling) {
            // Ускоряем падение
            fallSpeed += 1200 * dt; // Гравитация
            setY(getY() + fallSpeed * dt);
        }
    }

    /**
     * Получить прогресс таймера (для визуализации тряски)
     */
    public double getShakeIntensity() {
        if (activated && !falling) {
            // Чем ближе к падению, тем сильнее трясется
            return fallTimer / FALL_DELAY;
        }
        return 0;
    }

    public boolean isFalling() {
        return falling;
    }

    public boolean isActivated() {
        return activated;
    }

    /**
     * Платформа упала слишком низко - нужно удалить
     */
    public boolean shouldRemove() {
        return getY() > 700;
    }
}