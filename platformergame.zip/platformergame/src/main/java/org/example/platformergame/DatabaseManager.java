package org.example.platformergame;

import java.sql.*;
import java.time.LocalDateTime;

/**
 * Класс для работы с базой данных PostgreSQL
 * Управляет сохранением и загрузкой прогресса игрока
 */
public class DatabaseManager {

    // ========== НАСТРОЙКИ ПОДКЛЮЧЕНИЯ К POSTGRESQL ==========
    // ВАЖНО: Измените эти параметры под вашу базу данных!

    private static final String DB_HOST = "localhost";
    private static final String DB_PORT = "5432";
    private static final String DB_NAME = "platformergame";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "Bada2006"; // ЗАМЕНИТЕ НА ВАШ ПАРОЛЬ!

    private static final String DB_URL = String.format(
            "jdbc:postgresql://%s:%s/%s", DB_HOST, DB_PORT, DB_NAME
    );

    // Единственный экземпляр класса (Singleton)
    private static DatabaseManager instance;

    // Приватный конструктор для Singleton
    private DatabaseManager() {
        initializeDatabase();
    }

    /**
     * Получить экземпляр DatabaseManager
     */
    public static DatabaseManager getInstance() {
        if (instance == null) {
            instance = new DatabaseManager();
        }
        return instance;
    }

    /**
     * Получить соединение с базой данных
     */
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    /**
     * Инициализация базы данных - создание таблиц если их нет
     */
    private void initializeDatabase() {
        try (Connection conn = getConnection()) {

            // Создаём таблицу игроков
            String createPlayersTable = """
                CREATE TABLE IF NOT EXISTS players (
                    id SERIAL PRIMARY KEY,
                    name VARCHAR(100) NOT NULL UNIQUE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """;

            // Создаём таблицу прогресса игрока
            String createProgressTable = """
                CREATE TABLE IF NOT EXISTS player_progress (
                    id SERIAL PRIMARY KEY,
                    player_id INTEGER NOT NULL,
                    current_level INTEGER DEFAULT 1,
                    total_deaths INTEGER DEFAULT 0,
                    best_time REAL DEFAULT 0.0,
                    last_saved TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
                )
                """;

            // Создаём таблицу рекордов
            String createRecordsTable = """
                CREATE TABLE IF NOT EXISTS records (
                    id SERIAL PRIMARY KEY,
                    player_name VARCHAR(100) NOT NULL,
                    level INTEGER NOT NULL,
                    time REAL NOT NULL,
                    score INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """;

            // Выполняем создание таблиц
            Statement stmt = conn.createStatement();
            stmt.execute(createPlayersTable);
            stmt.execute(createProgressTable);
            stmt.execute(createRecordsTable);

            System.out.println("✅ База данных PostgreSQL успешно инициализирована!");

        } catch (SQLException e) {
            System.err.println("❌ Ошибка при инициализации базы данных: " + e.getMessage());
            System.err.println("💡 Проверьте:");
            System.err.println("   1. Запущен ли сервер PostgreSQL");
            System.err.println("   2. Существует ли база данных '" + DB_NAME + "'");
            System.err.println("   3. Правильные ли логин/пароль");
            e.printStackTrace();
        }
    }

    /**
     * Создать нового игрока или получить существующего
     * @param playerName имя игрока
     * @return ID игрока
     */
    public int createOrGetPlayer(String playerName) {
        try (Connection conn = getConnection()) {

            // Проверяем, существует ли игрок
            String checkQuery = "SELECT id FROM players WHERE name = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
            checkStmt.setString(1, playerName);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                // Игрок существует - возвращаем его ID
                return rs.getInt("id");
            }

            // Игрок не существует - создаём нового
            String insertQuery = "INSERT INTO players (name) VALUES (?) RETURNING id";
            PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
            insertStmt.setString(1, playerName);
            ResultSet generatedKeys = insertStmt.executeQuery();

            if (generatedKeys.next()) {
                int playerId = generatedKeys.getInt(1);

                // Создаём начальный прогресс для нового игрока
                createInitialProgress(playerId);

                System.out.println("✅ Создан новый игрок: " + playerName + " (ID: " + playerId + ")");
                return playerId;
            }

        } catch (SQLException e) {
            System.err.println("❌ Ошибка при создании/получении игрока: " + e.getMessage());
            e.printStackTrace();
        }

        return -1; // Ошибка
    }

    /**
     * Создать начальный прогресс для нового игрока
     */
    private void createInitialProgress(int playerId) {
        try (Connection conn = getConnection()) {

            String insertQuery = """
                INSERT INTO player_progress (player_id, current_level, total_deaths, best_time)
                VALUES (?, 1, 0, 0.0)
                """;

            PreparedStatement stmt = conn.prepareStatement(insertQuery);
            stmt.setInt(1, playerId);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.err.println("❌ Ошибка при создании начального прогресса: " + e.getMessage());
        }
    }

    /**
     * Сохранить прогресс игрока
     */
    public void saveProgress(int playerId, int currentLevel, int totalDeaths, double bestTime) {
        try (Connection conn = getConnection()) {

            // Обновляем существующий прогресс
            String updateQuery = """
                UPDATE player_progress 
                SET current_level = ?, 
                    total_deaths = ?, 
                    best_time = ?,
                    last_saved = ?
                WHERE player_id = ?
                """;

            PreparedStatement stmt = conn.prepareStatement(updateQuery);
            stmt.setInt(1, currentLevel);
            stmt.setInt(2, totalDeaths);
            stmt.setDouble(3, bestTime);
            stmt.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setInt(5, playerId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("✅ Прогресс сохранён! Уровень: " + currentLevel + ", Смерти: " + totalDeaths);
            } else {
                System.out.println("⚠️ Прогресс не найден для игрока ID: " + playerId);
            }

        } catch (SQLException e) {
            System.err.println("❌ Ошибка при сохранении прогресса: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Загрузить прогресс игрока
     * @return объект PlayerProgress или null если не найден
     */
    public PlayerProgress loadProgress(int playerId) {
        try (Connection conn = getConnection()) {

            String query = """
                SELECT current_level, total_deaths, best_time, last_saved
                FROM player_progress
                WHERE player_id = ?
                """;

            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, playerId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                PlayerProgress progress = new PlayerProgress();
                progress.playerId = playerId;
                progress.currentLevel = rs.getInt("current_level");
                progress.totalDeaths = rs.getInt("total_deaths");
                progress.bestTime = rs.getDouble("best_time");
                progress.lastSaved = rs.getTimestamp("last_saved").toString();

                System.out.println("✅ Прогресс загружен! Уровень: " + progress.currentLevel);
                return progress;
            }

        } catch (SQLException e) {
            System.err.println("❌ Ошибка при загрузке прогресса: " + e.getMessage());
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Сохранить рекорд прохождения уровня
     */
    public void saveRecord(String playerName, int level, double time, int score) {
        try (Connection conn = getConnection()) {

            String insertQuery = """
                INSERT INTO records (player_name, level, time, score)
                VALUES (?, ?, ?, ?)
                """;

            PreparedStatement stmt = conn.prepareStatement(insertQuery);
            stmt.setString(1, playerName);
            stmt.setInt(2, level);
            stmt.setDouble(3, time);
            stmt.setInt(4, score);
            stmt.executeUpdate();

            System.out.println("✅ Рекорд сохранён! " + playerName + " - Уровень " + level + " - Время: " + time);

        } catch (SQLException e) {
            System.err.println("❌ Ошибка при сохранении рекорда: " + e.getMessage());
        }
    }

    /**
     * Получить топ-10 рекордов для уровня
     */
    public void printTopRecords(int level) {
        try (Connection conn = getConnection()) {

            String query = """
                SELECT player_name, time, score, created_at
                FROM records
                WHERE level = ?
                ORDER BY time ASC, score DESC
                LIMIT 10
                """;

            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, level);
            ResultSet rs = stmt.executeQuery();

            System.out.println("\n🏆 ТОП-10 РЕКОРДОВ - УРОВЕНЬ " + level + " 🏆");
            System.out.println("═══════════════════════════════════════════");

            int position = 1;
            while (rs.next()) {
                String name = rs.getString("player_name");
                double time = rs.getDouble("time");
                int score = rs.getInt("score");
                String date = rs.getTimestamp("created_at").toString();

                System.out.printf("%d. %s | Время: %.2f сек | Очки: %d | %s\n",
                        position, name, time, score, date);
                position++;
            }

            System.out.println("═══════════════════════════════════════════\n");

        } catch (SQLException e) {
            System.err.println("❌ Ошибка при получении рекордов: " + e.getMessage());
        }
    }

    /**
     * Получить имя игрока по ID
     */
    public String getPlayerName(int playerId) {
        try (Connection conn = getConnection()) {

            String query = "SELECT name FROM players WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, playerId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getString("name");
            }

        } catch (SQLException e) {
            System.err.println("❌ Ошибка при получении имени игрока: " + e.getMessage());
        }

        return "Unknown";
    }

    // ========== НОВЫЕ МЕТОДЫ ДЛЯ СТАТИСТИКИ ==========

    /**
     * Получить статистику по уровню для игрока
     */
    public LevelStatistics getLevelStatistics(String playerName, int level) {
        try (Connection conn = getConnection()) {

            LevelStatistics stats = new LevelStatistics();

            // Получаем количество попыток и лучшее время игрока
            String playerQuery = """
                SELECT COUNT(*) as attempts, MIN(time) as best_time
                FROM records
                WHERE player_name = ? AND level = ?
                """;

            PreparedStatement playerStmt = conn.prepareStatement(playerQuery);
            playerStmt.setString(1, playerName);
            playerStmt.setInt(2, level);
            ResultSet playerRs = playerStmt.executeQuery();

            if (playerRs.next()) {
                stats.attempts = playerRs.getInt("attempts");
                stats.bestTime = playerRs.getDouble("best_time");
                if (stats.attempts == 0) {
                    stats.bestTime = 0.0;
                }
            }

            // Получаем общий рекорд уровня (лучшее время среди всех игроков)
            String recordQuery = """
                SELECT time, score
                FROM records
                WHERE level = ?
                ORDER BY time ASC
                LIMIT 1
                """;

            PreparedStatement recordStmt = conn.prepareStatement(recordQuery);
            recordStmt.setInt(1, level);
            ResultSet recordRs = recordStmt.executeQuery();

            if (recordRs.next()) {
                stats.topTime = recordRs.getDouble("time");
                stats.topScore = recordRs.getDouble("score");
            } else {
                stats.topTime = 0.0;
                stats.topScore = 0.0;
            }

            return stats;

        } catch (SQLException e) {
            System.err.println("❌ Ошибка при получении статистики уровня: " + e.getMessage());
            return null;
        }
    }

    /**
     * Сбросить всю статистику игрока
     */
    public void resetStatistics(String playerName) {
        try (Connection conn = getConnection()) {

            // Получаем ID игрока
            String getIdQuery = "SELECT id FROM players WHERE name = ?";
            PreparedStatement getIdStmt = conn.prepareStatement(getIdQuery);
            getIdStmt.setString(1, playerName);
            ResultSet rs = getIdStmt.executeQuery();

            if (!rs.next()) {
                System.out.println("⚠️ Игрок не найден");
                return;
            }

            int playerId = rs.getInt("id");

            // Сбрасываем прогресс
            String resetProgressQuery = """
                UPDATE player_progress 
                SET current_level = 1, total_deaths = 0, best_time = 0.0
                WHERE player_id = ?
                """;

            PreparedStatement resetProgressStmt = conn.prepareStatement(resetProgressQuery);
            resetProgressStmt.setInt(1, playerId);
            resetProgressStmt.executeUpdate();

            // Удаляем все рекорды игрока
            String deleteRecordsQuery = "DELETE FROM records WHERE player_name = ?";
            PreparedStatement deleteRecordsStmt = conn.prepareStatement(deleteRecordsQuery);
            deleteRecordsStmt.setString(1, playerName);
            deleteRecordsStmt.executeUpdate();

            System.out.println("✅ Статистика игрока " + playerName + " сброшена!");

        } catch (SQLException e) {
            System.err.println("❌ Ошибка при сбросе статистики: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ========== ВНУТРЕННИЕ КЛАССЫ ==========

    /**
     * Внутренний класс для хранения прогресса игрока
     */
    public static class PlayerProgress {
        public int playerId;
        public int currentLevel;
        public int totalDeaths;
        public double bestTime;
        public String lastSaved;

        @Override
        public String toString() {
            return String.format("Игрок ID: %d | Уровень: %d | Смерти: %d | Лучшее время: %.2f",
                    playerId, currentLevel, totalDeaths, bestTime);
        }
    }

    /**
     * Внутренний класс для хранения статистики уровня
     */
    public static class LevelStatistics {
        public int attempts;        // Количество попыток
        public double bestTime;     // Лучшее время игрока
        public double topTime;      // Лучший рекорд в таблице
        public double topScore;     // Очки за лучший рекорд

        @Override
        public String toString() {
            return String.format("Попыток: %d | Лучшее время: %.2f | Рекорд: %.2f (%.0f очков)",
                    attempts, bestTime, topTime, topScore);
        }
    }

    /**
     * Закрыть соединение с базой данных (вызывать при выходе из игры)
     */
    public void close() {
        System.out.println("✅ База данных закрыта");
    }
}