package org.example.platformergame;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class gameApplication extends Application {

    @Override
    public void start(Stage stage) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("Menu.fxml")
            );
            Parent root = loader.load();
            stage.setResizable(false);
            // ПЕРЕДАЁМ STAGE В КОНТРОЛЛЕР МЕНЮ
            MenuController controller = loader.getController();
            controller.setStage(stage);

            stage.setScene(new Scene(root, 900, 600));
            stage.setTitle("Platformer - Demo");
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch();
    }
}
