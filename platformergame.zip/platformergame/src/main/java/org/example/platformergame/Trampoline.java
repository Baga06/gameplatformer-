package org.example.platformergame;

/**
 * Трамплин - дает игроку сильный прыжок
 */
public class Trampoline {

    private double x, y;
    private final double width, height;
    private double bounceForce = -800; // Сила отскока (больше чем обычный прыжок)
    private boolean justBounced = false; // Для анимации сжатия
    private double compressionTimer = 0;

    public Trampoline(double x, double y, double width, double height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public double getWidth() { return width; }
    public double getHeight() { return height; }
    public double getBounceForce() { return bounceForce; }

    /**
     * Проверить столкновение с игроком (только сверху)
     */
    public boolean shouldBounce(Player player) {
        double px = player.getX();
        double py = player.getY();
        double pw = player.getWidth();
        double ph = player.getHeight();

        // Игрок должен падать сверху
        boolean fromAbove = player.getVelocityY() > 0;

        boolean intersects = px < x + width &&
                px + pw > x &&
                py + ph >= y &&
                py + ph <= y + height + 10;

        return intersects && fromAbove;
    }

    /**
     * Активировать отскок
     */
    public void bounce() {
        justBounced = true;
        compressionTimer = 0.2; // 0.2 секунды анимации
    }

    /**
     * Обновить состояние трамплина
     */
    public void update(double dt) {
        if (justBounced) {
            compressionTimer -= dt;
            if (compressionTimer <= 0) {
                justBounced = false;
            }
        }
    }

    /**
     * Получить степень сжатия для визуализации (0.0 - 1.0)
     */
    public double getCompression() {
        if (justBounced) {
            return 1.0 - (compressionTimer / 0.2);
        }
        return 0;
    }

    public boolean isJustBounced() {
        return justBounced;
    }
}