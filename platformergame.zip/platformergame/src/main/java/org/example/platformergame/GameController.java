package org.example.platformergame;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.util.*;

public class GameController {

    @FXML
    private Pane gamePane;

    @FXML
    private Label scoreLabel;

    @FXML
    private Label livesLabel;

    @FXML
    private Button pauseButton;

    private Player player;
    private Rectangle playerView;
    private final List<Platform> platforms = new ArrayList<>();
    private final List<Coin> coins = new ArrayList<>();
    private final List<Circle> coinViews = new ArrayList<>();
    private final List<Enemy> enemies = new ArrayList<>();
    private final List<Rectangle> enemyViews = new ArrayList<>();
    private final Map<KeyCode, Boolean> keys = new HashMap<>();
    private AnimationTimer gameLoop;
    private int score = 0;
    private boolean paused = false;
    private VBox pauseMenu;

    private final double START_X = 50;
    private final double START_Y = 400;

    @FXML
    public void initialize() {
        setupPlayer();
        setupPlatforms();
        setupCoins();
        setupEnemies();
        setupInput();
        setupPauseMenu();
        startLoop();
        updateUI();
    }

    private void setupPlayer() {
        player = new Player(START_X, START_Y, 36, 48);
        playerView = new Rectangle(player.getWidth(), player.getHeight());
        playerView.setFill(Color.DODGERBLUE);
        playerView.setStroke(Color.BLUE);
        playerView.setStrokeWidth(2);
        updatePlayerView();
        gamePane.getChildren().add(playerView);
    }

    private void setupPlatforms() {
        platforms.add(new Platform(0, 520, 900, 80));       // Земля
        platforms.add(new Platform(100, 440, 120, 20));     // Платформа 1
        platforms.add(new Platform(300, 380, 120, 20));     // Платформа 2
        platforms.add(new Platform(500, 320, 120, 20));     // Платформа 3
        platforms.add(new Platform(650, 280, 100, 20));     // Платформа 4
        platforms.add(new Platform(750, 200, 120, 20));     // Платформа 5

        for (Platform p : platforms) {
            Rectangle r = new Rectangle(p.getWidth(), p.getHeight());
            r.setFill(Color.DARKGRAY);
            r.setStroke(Color.BLACK);
            r.setStrokeWidth(1);
            r.setTranslateX(p.getX());
            r.setTranslateY(p.getY());
            gamePane.getChildren().add(0, r);
        }
    }

    private void setupCoins() {
        // Монеты на платформах
        coins.add(new Coin(150, 410, 20));
        coins.add(new Coin(350, 350, 20));
        coins.add(new Coin(550, 290, 20));
        coins.add(new Coin(680, 250, 20));
        coins.add(new Coin(800, 170, 20));
        coins.add(new Coin(200, 490, 20));
        coins.add(new Coin(400, 490, 20));
        coins.add(new Coin(600, 490, 20));

        for (Coin coin : coins) {
            Circle circle = new Circle(coin.getSize() / 2);
            circle.setFill(Color.GOLD);
            circle.setStroke(Color.ORANGE);
            circle.setStrokeWidth(2);
            circle.setTranslateX(coin.getX() + coin.getSize() / 2);
            circle.setTranslateY(coin.getY() + coin.getSize() / 2);
            coinViews.add(circle);
            gamePane.getChildren().add(circle);
        }
    }

    private void setupEnemies() {
        // Враги патрулируют платформы
        enemies.add(new Enemy(110, 412, 30, 30, 100, 200, 60));
        enemies.add(new Enemy(310, 352, 30, 30, 300, 400, 50));
        enemies.add(new Enemy(510, 292, 30, 30, 500, 600, 70));

        for (Enemy enemy : enemies) {
            Rectangle rect = new Rectangle(enemy.getWidth(), enemy.getHeight());
            rect.setFill(Color.DARKRED);
            rect.setStroke(Color.RED);
            rect.setStrokeWidth(2);
            rect.setTranslateX(enemy.getX());
            rect.setTranslateY(enemy.getY());
            enemyViews.add(rect);
            gamePane.getChildren().add(rect);
        }
    }

    private void setupInput() {
        gamePane.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                newScene.setOnKeyPressed(e -> {
                    keys.put(e.getCode(), true);
                    if (e.getCode() == KeyCode.ESCAPE) {
                        togglePause();
                    }
                });
                newScene.setOnKeyReleased(e -> keys.put(e.getCode(), false));
            }
        });
    }

    private void setupPauseMenu() {
        pauseMenu = new VBox(20);
        pauseMenu.setStyle("-fx-background-color: rgba(0, 0, 0, 0.8); -fx-padding: 40; -fx-alignment: center;");
        pauseMenu.setPrefSize(300, 250);
        pauseMenu.setLayoutX(300);
        pauseMenu.setLayoutY(175);
        pauseMenu.setVisible(false);

        Label pauseLabel = new Label("ПАУЗА");
        pauseLabel.setStyle("-fx-font-size: 32; -fx-text-fill: white; -fx-font-weight: bold;");

        Button resumeBtn = new Button("Продолжить");
        resumeBtn.setStyle("-fx-font-size: 16; -fx-pref-width: 200;");
        resumeBtn.setOnAction(e -> togglePause());

        Button menuBtn = new Button("В меню");
        menuBtn.setStyle("-fx-font-size: 16; -fx-pref-width: 200;");
        menuBtn.setOnAction(e -> returnToMenu());

        Button exitBtn = new Button("Выход");
        exitBtn.setStyle("-fx-font-size: 16; -fx-pref-width: 200;");
        exitBtn.setOnAction(e -> System.exit(0));

        pauseMenu.getChildren().addAll(pauseLabel, resumeBtn, menuBtn, exitBtn);
        gamePane.getChildren().add(pauseMenu);
    }

    @FXML
    private void onPause() {
        togglePause();
    }

    private void togglePause() {
        paused = !paused;
        pauseMenu.setVisible(paused);
        if (paused) {
            pauseButton.setText("Продолжить");
        } else {
            pauseButton.setText("Пауза");
        }
    }

    private void returnToMenu() {
        try {
            gameLoop.stop();
            Stage stage = (Stage) gamePane.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
            Parent root = loader.load();
            MenuController controller = loader.getController();
            controller.setStage(stage);
            stage.setScene(new Scene(root, 900, 600));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onReset() {
        player.reset(START_X, START_Y);
        score = 0;

        // Сброс монет
        for (int i = 0; i < coins.size(); i++) {
            if (coins.get(i).isCollected()) {
                coinViews.get(i).setVisible(true);
            }
        }
        coins.clear();
        setupCoins();

        updatePlayerView();
        updateUI();
    }

    private void startLoop() {
        gameLoop = new AnimationTimer() {
            private long last = 0;

            @Override
            public void handle(long now) {
                if (last == 0) last = now;
                double delta = (now - last) / 1_000_000_000.0;

                if (!paused && !player.isDead()) {
                    update(delta);
                    render();
                }

                last = now;
            }
        };
        gameLoop.start();
    }

    private void update(double dt) {
        player.savePrevPosition();

        // Управление
        if (isPressed(KeyCode.A) || isPressed(KeyCode.LEFT)) {
            player.moveX(-220 * dt);
        }
        if (isPressed(KeyCode.D) || isPressed(KeyCode.RIGHT)) {
            player.moveX(220 * dt);
        }
        if ((isPressed(KeyCode.SPACE) || isPressed(KeyCode.W) || isPressed(KeyCode.UP))
                && player.isOnGround()) {
            player.jump();
        }

        // Физика
        player.applyGravity(dt);

        // Проверка коллизий
        checkCollisions();

        // Границы экрана
        if (player.getX() < 0) player.setX(0);
        if (player.getX() + player.getWidth() > 900) {
            player.setX(900 - player.getWidth());
        }

        // Проверка падения в бездну
        if (player.getY() > 600) {
            player.loseLife();
            if (!player.isDead()) {
                respawnPlayer();
            } else {
                gameOver();
            }
        }

        // Обновление врагов
        for (int i = 0; i < enemies.size(); i++) {
            enemies.get(i).update(dt);
            enemyViews.get(i).setTranslateX(enemies.get(i).getX());
        }

        // Проверка столкновения с врагами
        for (Enemy enemy : enemies) {
            if (enemy.intersects(player)) {
                player.loseLife();
                if (!player.isDead()) {
                    respawnPlayer();
                } else {
                    gameOver();
                }
                break;
            }
        }

        // Сбор монет
        for (int i = 0; i < coins.size(); i++) {
            Coin coin = coins.get(i);
            if (!coin.isCollected() && coin.intersects(player)) {
                coin.collect();
                coinViews.get(i).setVisible(false);
                score += 10;
            }
        }

        updateUI();
    }

    private void checkCollisions() {
        player.setOnGround(false);

        for (Platform p : platforms) {
            if (player.intersects(p)) {
                resolveCollision(p);
            }
        }
    }

    private void resolveCollision(Platform p) {
        double playerBottom = player.getY() + player.getHeight();
        double playerPrevBottom = player.getPrevY() + player.getHeight();
        double platformTop = p.getY();
        double platformBottom = p.getY() + p.getHeight();

        boolean fromAbove = playerPrevBottom <= platformTop + 5;
        boolean fromBelow = player.getPrevY() >= platformBottom - 5;
        boolean fromLeft = player.getPrevX() + player.getWidth() <= p.getX() + 5;
        boolean fromRight = player.getPrevX() >= p.getX() + p.getWidth() - 5;

        double overlapX = Math.min(
                player.getX() + player.getWidth() - p.getX(),
                p.getX() + p.getWidth() - player.getX()
        );
        double overlapY = Math.min(
                player.getY() + player.getHeight() - p.getY(),
                p.getY() + p.getHeight() - player.getY()
        );

        if (overlapX < overlapY) {
            if (fromLeft) {
                player.setX(p.getX() - player.getWidth());
            } else if (fromRight) {
                player.setX(p.getX() + p.getWidth());
            }
        } else {
            if (fromAbove && player.getVelocityY() >= 0) {
                player.landOn(platformTop - player.getHeight());
                player.setOnGround(true);
            } else if (fromBelow && player.getVelocityY() <= 0) {
                player.setY(platformBottom);
                player.setVelocityY(0);
            }
        }
    }

    private void respawnPlayer() {
        player.setX(START_X);
        player.setY(START_Y);
        player.resetVelocity();
        player.setOnGround(false);
    }

    private void gameOver() {
        paused = true;
        Label gameOverLabel = new Label("GAME OVER");
        gameOverLabel.setStyle("-fx-font-size: 48; -fx-text-fill: red; -fx-font-weight: bold;");
        gameOverLabel.setLayoutX(300);
        gameOverLabel.setLayoutY(250);
        gamePane.getChildren().add(gameOverLabel);
    }

    private void render() {
        updatePlayerView();
    }

    private void updatePlayerView() {
        playerView.setTranslateX(player.getX());
        playerView.setTranslateY(player.getY());
    }

    private void updateUI() {
        scoreLabel.setText("Score: " + score);
        livesLabel.setText("Lives: " + player.getLives());
    }

    private boolean isPressed(KeyCode key) {
        return keys.getOrDefault(key, false);
    }
}