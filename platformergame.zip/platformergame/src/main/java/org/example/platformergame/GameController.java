package org.example.platformergame;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.util.*;

public class GameController {

    @FXML
    private Pane gamePane;

    @FXML
    private Label scoreLabel;

    @FXML
    private Label livesLabel;

    @FXML
    private Button pauseButton;

    private Player player;
    private Rectangle playerView;
    private final List<Platform> platforms = new ArrayList<>();
    private final List<Rectangle> platformViews = new ArrayList<>();
    private final List<Coin> coins = new ArrayList<>();
    private final List<Circle> coinViews = new ArrayList<>();
    private final Map<KeyCode, Boolean> keys = new HashMap<>();
    private boolean wKeyWasPressed = false;
    private AnimationTimer gameLoop;
    private int score = 0;
    private boolean paused = false;
    private VBox pauseMenu;
    private VBox gameOverMenu;
    private VBox levelCompleteMenu;
    private Rectangle pauseOverlay;
    private int currentLevel = 1;
    private double cameraX = 0;
    private Rectangle finishLine;

    // ========== ПОЛЯ ДЛЯ РАБОТЫ С БАЗОЙ ДАННЫХ ==========
    private DatabaseManager db;
    private int currentPlayerId = -1;
    private String currentPlayerName = "Player1"; // Можно изменить на запрос у пользователя
    private int totalDeaths = 0;
    private long levelStartTime = 0;

    private final double START_X = 50;
    private final double START_Y = 400;
    private final double LEVEL_WIDTH = 3600;
    private final double SCREEN_WIDTH = 900;

    @FXML
    public void initialize() {
        // ========== ИНИЦИАЛИЗАЦИЯ БАЗЫ ДАННЫХ ==========
        try {
            db = DatabaseManager.getInstance();
            currentPlayerId = db.createOrGetPlayer(currentPlayerName);
            loadPlayerProgress();
        } catch (Exception e) {
            System.err.println("⚠️ Не удалось подключиться к базе данных: " + e.getMessage());
            System.err.println("⚠️ Игра продолжит работу без сохранения прогресса");
        }

        setupPlayer();
        setupInput();
        setupPauseOverlay();
        setupPauseMenu();
        setupGameOverMenu();
        setupLevelCompleteMenu();
        startLoop();
        updateUI();
    }

    public void setLevel(int level) {
        this.currentLevel = level;
        loadLevel(level);
        levelStartTime = System.currentTimeMillis();
    }

    private void loadLevel(int level) {
        platforms.clear();
        platformViews.clear();
        coins.clear();
        coinViews.clear();
        cameraX = 0;
        finishLine = null;

        gamePane.getChildren().removeIf(node ->
                node != playerView && node != pauseOverlay && node != pauseMenu &&
                        node != gameOverMenu && node != levelCompleteMenu
        );

        switch (level) {
            case 1:
                setupLevel1();
                break;
            case 2:
                setupLevel2();
                break;
            case 3:
                setupLevel3();
                break;
            default:
                setupLevel1();
        }

        levelStartTime = System.currentTimeMillis();
    }

    private void setupLevel1() {
        addPlatform(0, 520, 3600, 80, Color.BROWN.darker());
        addPlatform(150, 450, 120, 20, Color.GREEN.darker());
        addPlatform(320, 400, 100, 20, Color.GREEN.darker());
        addCoin(180, 420);
        addCoin(350, 370);
        addCoin(200, 490);

        addPlatform(650, 450, 100, 20, Color.LIGHTBLUE.darker());
        addPlatform(800, 400, 100, 20, Color.LIGHTBLUE.darker());
        addPlatform(950, 350, 100, 20, Color.LIGHTBLUE.darker());
        addPlatform(1100, 300, 100, 20, Color.LIGHTBLUE.darker());
        addCoin(680, 420);
        addCoin(830, 370);
        addCoin(980, 320);
        addCoin(1130, 270);

        addPlatform(1250, 250, 120, 20, Color.PURPLE.darker());
        addPlatform(1450, 200, 100, 20, Color.PURPLE.darker());
        addPlatform(1600, 250, 120, 20, Color.PURPLE.darker());
        addCoin(1280, 220);
        addCoin(1480, 170);
        addCoin(1630, 220);
        addCoin(1350, 490);
        addCoin(1550, 490);

        addPlatform(1900, 450, 80, 20, Color.ORANGE.darker());
        addPlatform(2050, 400, 80, 20, Color.ORANGE.darker());
        addPlatform(2200, 450, 80, 20, Color.ORANGE.darker());
        addPlatform(2350, 380, 100, 20, Color.ORANGE.darker());
        addCoin(1920, 420);
        addCoin(2070, 370);
        addCoin(2220, 420);
        addCoin(2380, 350);
        addCoin(2000, 490);

        addPlatform(2500, 350, 100, 20, Color.RED.darker());
        addPlatform(2650, 300, 80, 20, Color.RED.darker());
        addPlatform(2780, 250, 80, 20, Color.RED.darker());
        addPlatform(2900, 200, 100, 20, Color.RED.darker());
        addPlatform(2700, 450, 100, 20, Color.RED.darker());
        addCoin(2530, 320);
        addCoin(2670, 270);
        addCoin(2800, 220);
        addCoin(2930, 170);
        addCoin(2730, 420);
        addCoin(2600, 490);
        addCoin(2800, 490);

        addPlatform(3050, 350, 100, 20, Color.GOLD.darker());
        addPlatform(3200, 400, 120, 20, Color.GOLD.darker());
        addPlatform(3350, 450, 100, 20, Color.GOLD.darker());
        addCoin(3080, 320);
        addCoin(3230, 370);
        addCoin(3380, 420);
        addCoin(3150, 490);
        addCoin(3300, 490);

        finishLine = new Rectangle(50, 150);
        finishLine.setFill(Color.rgb(255, 215, 0, 0.7));
        finishLine.setStroke(Color.GOLD);
        finishLine.setStrokeWidth(3);
        finishLine.setTranslateX(3500);
        finishLine.setTranslateY(370);
        gamePane.getChildren().add(finishLine);
    }

    private void setupLevel2() {
        addPlatform(0, 520, 3600, 80, Color.SADDLEBROWN);
        addPlatform(100, 440, 120, 20, Color.DARKORANGE);
        addPlatform(280, 380, 100, 20, Color.DARKORANGE);
        addPlatform(460, 320, 120, 20, Color.DARKORANGE);
        addCoin(130, 410);
        addCoin(310, 350);
        addCoin(490, 290);
        addCoin(200, 490);

        addPlatform(700, 380, 100, 20, Color.ORANGE.darker());
        addPlatform(850, 320, 100, 20, Color.ORANGE.darker());
        addPlatform(1000, 260, 100, 20, Color.ORANGE.darker());
        addPlatform(1150, 320, 100, 20, Color.ORANGE.darker());
        addCoin(730, 350);
        addCoin(880, 290);
        addCoin(1030, 230);
        addCoin(1180, 290);
        addCoin(900, 490);

        addPlatform(1300, 200, 80, 20, Color.CORAL);
        addPlatform(1450, 280, 80, 20, Color.CORAL);
        addPlatform(1600, 200, 80, 20, Color.CORAL);
        addPlatform(1750, 280, 80, 20, Color.CORAL);
        addCoin(1320, 170);
        addCoin(1470, 250);
        addCoin(1620, 170);
        addCoin(1770, 250);
        addCoin(1500, 490);
        addCoin(1650, 490);

        addPlatform(1900, 450, 100, 20, Color.SANDYBROWN);
        addPlatform(2050, 380, 100, 20, Color.SANDYBROWN);
        addPlatform(2200, 310, 100, 20, Color.SANDYBROWN);
        addPlatform(2350, 240, 100, 20, Color.SANDYBROWN);
        addPlatform(2500, 170, 120, 20, Color.SANDYBROWN);
        addCoin(1930, 420);
        addCoin(2080, 350);
        addCoin(2230, 280);
        addCoin(2380, 210);
        addCoin(2530, 140);
        addCoin(2000, 490);
        addCoin(2250, 490);

        addPlatform(2700, 350, 80, 20, Color.PERU);
        addPlatform(2900, 300, 80, 20, Color.PERU);
        addPlatform(3100, 250, 80, 20, Color.PERU);
        addCoin(2720, 320);
        addCoin(2920, 270);
        addCoin(3120, 220);
        addCoin(2800, 490);
        addCoin(3000, 490);

        addPlatform(3250, 380, 120, 20, Color.GOLD.darker());
        addPlatform(3400, 450, 100, 20, Color.GOLD.darker());
        addCoin(3280, 350);
        addCoin(3430, 420);
        addCoin(3300, 490);

        finishLine = new Rectangle(50, 150);
        finishLine.setFill(Color.rgb(255, 165, 0, 0.7));
        finishLine.setStroke(Color.ORANGE);
        finishLine.setStrokeWidth(3);
        finishLine.setTranslateX(3500);
        finishLine.setTranslateY(370);
        gamePane.getChildren().add(finishLine);
    }

    private void setupLevel3() {
        addPlatform(0, 520, 3600, 80, Color.DARKRED.darker());
        addPlatform(100, 450, 70, 20, Color.CRIMSON);
        addPlatform(250, 400, 70, 20, Color.CRIMSON);
        addPlatform(400, 350, 70, 20, Color.CRIMSON);
        addPlatform(550, 300, 70, 20, Color.CRIMSON);
        addCoin(120, 420);
        addCoin(270, 370);
        addCoin(420, 320);
        addCoin(570, 270);
        addCoin(300, 490);

        addPlatform(700, 380, 60, 20, Color.FIREBRICK);
        addPlatform(850, 320, 60, 20, Color.FIREBRICK);
        addPlatform(1000, 260, 60, 20, Color.FIREBRICK);
        addPlatform(1150, 200, 60, 20, Color.FIREBRICK);
        addPlatform(1300, 260, 60, 20, Color.FIREBRICK);
        addCoin(720, 350);
        addCoin(870, 290);
        addCoin(1020, 230);
        addCoin(1170, 170);
        addCoin(1320, 230);
        addCoin(900, 490);
        addCoin(1100, 490);

        addPlatform(1450, 150, 80, 20, Color.MAROON);
        addPlatform(1600, 250, 80, 20, Color.MAROON);
        addPlatform(1750, 150, 80, 20, Color.MAROON);
        addPlatform(1900, 100, 100, 20, Color.MAROON);
        addCoin(1470, 120);
        addCoin(1620, 220);
        addCoin(1770, 120);
        addCoin(1930, 70);
        addCoin(1550, 490);
        addCoin(1750, 490);

        addPlatform(2050, 200, 70, 20, Color.INDIANRED);
        addPlatform(2180, 300, 70, 20, Color.INDIANRED);
        addPlatform(2310, 200, 70, 20, Color.INDIANRED);
        addPlatform(2440, 350, 70, 20, Color.INDIANRED);
        addPlatform(2570, 250, 70, 20, Color.INDIANRED);
        addPlatform(2700, 400, 70, 20, Color.INDIANRED);
        addCoin(2070, 170);
        addCoin(2200, 270);
        addCoin(2330, 170);
        addCoin(2460, 320);
        addCoin(2590, 220);
        addCoin(2720, 370);
        addCoin(2200, 490);
        addCoin(2400, 490);
        addCoin(2600, 490);

        addPlatform(2850, 300, 65, 20, Color.RED.darker());
        addPlatform(3000, 200, 65, 20, Color.RED.darker());
        addPlatform(3150, 300, 65, 20, Color.RED.darker());
        addPlatform(3300, 200, 65, 20, Color.RED.darker());
        addCoin(2870, 270);
        addCoin(3020, 170);
        addCoin(3170, 270);
        addCoin(3320, 170);
        addCoin(2950, 490);
        addCoin(3100, 490);
        addCoin(3250, 490);

        addPlatform(3450, 350, 100, 20, Color.GOLD.darker());
        addCoin(3480, 320);
        addCoin(3400, 490);

        finishLine = new Rectangle(50, 150);
        finishLine.setFill(Color.rgb(255, 0, 0, 0.7));
        finishLine.setStroke(Color.RED);
        finishLine.setStrokeWidth(3);
        finishLine.setTranslateX(3500);
        finishLine.setTranslateY(370);
        gamePane.getChildren().add(finishLine);
    }

    private void addPlatform(double x, double y, double width, double height, Color color) {
        Platform p = new Platform(x, y, width, height, color);
        platforms.add(p);

        Rectangle r = new Rectangle(width, height);
        r.setFill(color);
        r.setStroke(color.darker());
        r.setStrokeWidth(2);
        r.setTranslateX(x);
        r.setTranslateY(y);
        platformViews.add(r);
        gamePane.getChildren().add(0, r);
    }

    private void addCoin(double x, double y) {
        Coin coin = new Coin(x, y, 20);
        coins.add(coin);

        Circle circle = new Circle(coin.getSize() / 2);
        circle.setFill(Color.GOLD);
        circle.setStroke(Color.ORANGE);
        circle.setStrokeWidth(2);
        circle.setTranslateX(coin.getX() + coin.getSize() / 2);
        circle.setTranslateY(coin.getY() + coin.getSize() / 2);
        coinViews.add(circle);
        gamePane.getChildren().add(circle);
    }

    // ========== МЕТОДЫ ДЛЯ РАБОТЫ С БАЗОЙ ДАННЫХ ==========

    /**
     * Загрузить прогресс игрока из базы данных
     */
    private void loadPlayerProgress() {
        if (currentPlayerId == -1 || db == null) return;

        try {
            DatabaseManager.PlayerProgress progress = db.loadProgress(currentPlayerId);
            if (progress != null) {
                currentLevel = progress.currentLevel;
                totalDeaths = progress.totalDeaths;
                System.out.println("📊 Прогресс загружен из БД: " + progress);
            }
        } catch (Exception e) {
            System.err.println("⚠️ Ошибка загрузки прогресса: " + e.getMessage());
        }
    }

    /**
     * Сохранить прогресс игрока в базу данных
     */
    private void savePlayerProgress() {
        if (currentPlayerId == -1 || db == null) return;

        try {
            double currentTime = (System.currentTimeMillis() - levelStartTime) / 1000.0;
            db.saveProgress(currentPlayerId, currentLevel, totalDeaths, currentTime);
        } catch (Exception e) {
            System.err.println("⚠️ Ошибка сохранения прогресса: " + e.getMessage());
        }
    }

    /**
     * Сохранить рекорд прохождения уровня
     */
    private void saveRecord() {
        if (currentPlayerId == -1 || db == null) return;

        try {
            double time = (System.currentTimeMillis() - levelStartTime) / 1000.0;
            String playerName = db.getPlayerName(currentPlayerId);
            db.saveRecord(playerName, currentLevel, time, score);

            // Показать топ рекордов (опционально)
            // db.printTopRecords(currentLevel);
        } catch (Exception e) {
            System.err.println("⚠️ Ошибка сохранения рекорда: " + e.getMessage());
        }
    }

    // ========== ОСТАЛЬНЫЕ МЕТОДЫ ==========

    private void loadNextLevel() {
        levelCompleteMenu.setVisible(false);
        pauseOverlay.setVisible(false);

        if (currentLevel < 3) {
            currentLevel++;
            player.reset(START_X, START_Y);
            score = 0;
            loadLevel(currentLevel);
            paused = false;
            updateUI();

            savePlayerProgress(); // Сохраняем при переходе на новый уровень
        } else {
            showAllLevelsComplete();
        }
    }

    private void showAllLevelsComplete() {
        levelCompleteMenu.setVisible(false);
        pauseOverlay.setVisible(true);
        pauseOverlay.toFront();

        VBox allCompleteMenu = new VBox(30);
        allCompleteMenu.setStyle("-fx-background-color: rgba(255, 215, 0, 0.95); -fx-padding: 50; -fx-alignment: center; -fx-border-color: gold; -fx-border-width: 5;");
        allCompleteMenu.setPrefSize(450, 350);
        allCompleteMenu.setLayoutX(225);
        allCompleteMenu.setLayoutY(125);

        Label congratsLabel = new Label("🎉 ПОЗДРАВЛЯЕМ! 🎉");
        congratsLabel.setStyle("-fx-font-size: 42; -fx-text-fill: #FF6B00; -fx-font-weight: bold;");

        Label messageLabel = new Label("Вы прошли все уровни!");
        messageLabel.setStyle("-fx-font-size: 24; -fx-text-fill: #8B4513;");

        Label scoreLabel = new Label("Финальный счет: " + score);
        scoreLabel.setStyle("-fx-font-size: 20; -fx-text-fill: #8B4513;");

        Button menuBtn = new Button("🏠 В меню");
        menuBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 280; -fx-pref-height: 50; -fx-background-color: #3498DB; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        menuBtn.setOnAction(e -> {
            gamePane.getChildren().remove(allCompleteMenu);
            returnToMenu();
        });

        Button exitBtn = new Button("✕ Выход");
        exitBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 280; -fx-pref-height: 50; -fx-background-color: #E74C3C; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        exitBtn.setOnAction(e -> System.exit(0));

        allCompleteMenu.getChildren().addAll(congratsLabel, messageLabel, scoreLabel, menuBtn, exitBtn);
        gamePane.getChildren().add(allCompleteMenu);
        allCompleteMenu.toFront();

        savePlayerProgress(); // Финальное сохранение
    }

    private void setupPlayer() {
        player = new Player(START_X, START_Y, 36, 48);
        playerView = new Rectangle(player.getWidth(), player.getHeight());
        playerView.setFill(Color.DODGERBLUE);
        playerView.setStroke(Color.BLUE);
        playerView.setStrokeWidth(2);
        updatePlayerView();
        gamePane.getChildren().add(playerView);
    }

    private void setupInput() {
        gamePane.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                newScene.setOnKeyPressed(e -> {
                    keys.put(e.getCode(), true);
                    if (e.getCode() == KeyCode.ESCAPE) {
                        togglePause();
                    }
                });
                newScene.setOnKeyReleased(e -> keys.put(e.getCode(), false));
            }
        });
    }

    private void setupPauseOverlay() {
        pauseOverlay = new Rectangle(900, 600);
        pauseOverlay.setFill(Color.rgb(0, 0, 0, 0.7));
        pauseOverlay.setVisible(false);
        gamePane.getChildren().add(pauseOverlay);
    }

    private void setupPauseMenu() {
        pauseMenu = new VBox(20);
        pauseMenu.setStyle("-fx-background-color: rgba(0, 0, 0, 0.95); -fx-padding: 40; -fx-alignment: center; -fx-border-color: white; -fx-border-width: 3;");
        pauseMenu.setPrefSize(300, 250);
        pauseMenu.setLayoutX(300);
        pauseMenu.setLayoutY(175);
        pauseMenu.setVisible(false);

        Label pauseLabel = new Label("ПАУЗА");
        pauseLabel.setStyle("-fx-font-size: 32; -fx-text-fill: white; -fx-font-weight: bold;");

        Button resumeBtn = new Button("Продолжить");
        resumeBtn.setStyle("-fx-font-size: 16; -fx-pref-width: 200;");
        resumeBtn.setOnAction(e -> togglePause());

        Button menuBtn = new Button("В меню");
        menuBtn.setStyle("-fx-font-size: 16; -fx-pref-width: 200;");
        menuBtn.setOnAction(e -> returnToMenu());

        Button exitBtn = new Button("Выход");
        exitBtn.setStyle("-fx-font-size: 16; -fx-pref-width: 200;");
        exitBtn.setOnAction(e -> System.exit(0));

        pauseMenu.getChildren().addAll(pauseLabel, resumeBtn, menuBtn, exitBtn);
        gamePane.getChildren().add(pauseMenu);
    }

    private void setupGameOverMenu() {
        gameOverMenu = new VBox(25);
        gameOverMenu.setStyle("-fx-background-color: rgba(139, 0, 0, 0.9); -fx-padding: 50; -fx-alignment: center; -fx-border-color: red; -fx-border-width: 3;");
        gameOverMenu.setPrefSize(400, 350);
        gameOverMenu.setLayoutX(250);
        gameOverMenu.setLayoutY(125);
        gameOverMenu.setVisible(false);

        Label gameOverLabel = new Label("GAME OVER");
        gameOverLabel.setStyle("-fx-font-size: 48; -fx-text-fill: #FF6B6B; -fx-font-weight: bold;");

        Label finalScoreLabel = new Label("Финальный счет: 0");
        finalScoreLabel.setStyle("-fx-font-size: 24; -fx-text-fill: white;");
        finalScoreLabel.setId("finalScoreLabel");

        Button restartBtn = new Button("🔄 Играть снова");
        restartBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 250; -fx-pref-height: 50; -fx-background-color: #27AE60; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        restartBtn.setOnAction(e -> restartGame());

        Button menuBtn = new Button("🏠 В меню");
        menuBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 250; -fx-pref-height: 50; -fx-background-color: #3498DB; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        menuBtn.setOnAction(e -> returnToMenu());

        Button exitBtn = new Button("✕ Выход");
        exitBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 250; -fx-pref-height: 50; -fx-background-color: #E74C3C; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        exitBtn.setOnAction(e -> System.exit(0));

        gameOverMenu.getChildren().addAll(gameOverLabel, finalScoreLabel, restartBtn, menuBtn, exitBtn);
        gamePane.getChildren().add(gameOverMenu);
    }

    private void setupLevelCompleteMenu() {
        levelCompleteMenu = new VBox(25);
        levelCompleteMenu.setStyle("-fx-background-color: rgba(0, 139, 0, 0.9); -fx-padding: 50; -fx-alignment: center; -fx-border-color: lime; -fx-border-width: 3;");
        levelCompleteMenu.setPrefSize(400, 400);
        levelCompleteMenu.setLayoutX(250);
        levelCompleteMenu.setLayoutY(100);
        levelCompleteMenu.setVisible(false);

        Label completeLabel = new Label("УРОВЕНЬ ПРОЙДЕН!");
        completeLabel.setStyle("-fx-font-size: 40; -fx-text-fill: #90EE90; -fx-font-weight: bold;");

        Label scoreLabel = new Label("Счет: 0");
        scoreLabel.setStyle("-fx-font-size: 24; -fx-text-fill: white;");
        scoreLabel.setId("levelCompleteScore");

        Label coinsLabel = new Label("Вы добрались до финиша!");
        coinsLabel.setStyle("-fx-font-size: 20; -fx-text-fill: white;");
        coinsLabel.setId("levelCompleteCoins");

        Button nextBtn = new Button("➡️ Следующий уровень");
        nextBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 280; -fx-pref-height: 50; -fx-background-color: #27AE60; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        nextBtn.setOnAction(e -> loadNextLevel());
        nextBtn.setId("nextLevelBtn");

        Button retryBtn = new Button("🔄 Повторить уровень");
        retryBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 280; -fx-pref-height: 50; -fx-background-color: #F39C12; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        retryBtn.setOnAction(e -> restartGame());

        Button menuBtn = new Button("🏠 В меню");
        menuBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 280; -fx-pref-height: 50; -fx-background-color: #3498DB; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        menuBtn.setOnAction(e -> returnToMenu());

        levelCompleteMenu.getChildren().addAll(completeLabel, scoreLabel, coinsLabel, nextBtn, retryBtn, menuBtn);
        gamePane.getChildren().add(levelCompleteMenu);
    }

    @FXML
    private void onPause() {
        togglePause();
    }

    private void togglePause() {
        paused = !paused;
        pauseOverlay.setVisible(paused);
        pauseMenu.setVisible(paused);

        if (paused) {
            pauseButton.setText("Продолжить");
            pauseOverlay.toFront();
            pauseMenu.toFront();
        } else {
            pauseButton.setText("Пауза");
        }
    }

    private void returnToMenu() {
        try {
            savePlayerProgress(); // Сохраняем перед выходом

            gameLoop.stop();
            Stage stage = (Stage) gamePane.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
            Parent root = loader.load();
            MenuController controller = loader.getController();
            controller.setStage(stage);
            stage.setScene(new Scene(root, 900, 600));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onReset() {
        restartGame();
    }

    private void restartGame() {
        gameOverMenu.setVisible(false);
        levelCompleteMenu.setVisible(false);
        pauseOverlay.setVisible(false);

        player.reset(START_X, START_Y);
        score = 0;
        cameraX = 0;

        loadLevel(currentLevel);

        paused = false;
        pauseButton.setText("Пауза");

        updatePlayerView();
        updateUI();
    }

    private void startLoop() {
        gameLoop = new AnimationTimer() {
            private long last = 0;

            @Override
            public void handle(long now) {
                if (last == 0) last = now;
                double delta = (now - last) / 1_000_000_000.0;

                if (!paused && !player.isDead()) {
                    update(delta);
                    render();
                }

                last = now;
            }
        };
        gameLoop.start();
    }

    private void update(double dt) {
        player.savePrevPosition();

        if (isPressed(KeyCode.A)) {
            player.moveX(-220 * dt);
        }
        if (isPressed(KeyCode.D)) {
            player.moveX(220 * dt);
        }

        boolean wKeyPressed = isPressed(KeyCode.W);
        if (wKeyPressed && !wKeyWasPressed) {
            player.jump();
        }
        wKeyWasPressed = wKeyPressed;

        player.applyGravity(dt);
        checkCollisions();

        if (player.getX() < 0) player.setX(0);
        if (player.getX() + player.getWidth() > LEVEL_WIDTH) {
            player.setX(LEVEL_WIDTH - player.getWidth());
        }

        updateCamera();

        if (player.getY() > 600) {
            player.loseLife();
            totalDeaths++; // Увеличиваем счётчик смертей

            if (!player.isDead()) {
                respawnPlayer();
            } else {
                gameOver();
            }
        }

        for (int i = 0; i < coins.size(); i++) {
            Coin coin = coins.get(i);
            if (!coin.isCollected() && coin.intersects(player)) {
                coin.collect();
                coinViews.get(i).setVisible(false);
                score += 10;
            }
        }

        if (finishLine != null) {
            double finishX = 3500;
            double finishY = 370;
            double finishW = 50;
            double finishH = 150;

            if (player.getX() + player.getWidth() > finishX &&
                    player.getX() < finishX + finishW &&
                    player.getY() + player.getHeight() > finishY &&
                    player.getY() < finishY + finishH) {
                levelComplete();
            }
        }

        updateUI();
    }

    private void updateCamera() {
        double targetCameraX = player.getX() - SCREEN_WIDTH / 2;

        if (targetCameraX < 0) targetCameraX = 0;
        if (targetCameraX > LEVEL_WIDTH - SCREEN_WIDTH) {
            targetCameraX = LEVEL_WIDTH - SCREEN_WIDTH;
        }

        cameraX = targetCameraX;
    }

    private void levelComplete() {
        paused = true;

        pauseOverlay.setVisible(true);
        pauseOverlay.toFront();

        saveRecord(); // Сохраняем рекорд
        savePlayerProgress(); // Сохраняем прогресс

        for (javafx.scene.Node node : levelCompleteMenu.getChildren()) {
            if (node instanceof Label) {
                Label label = (Label) node;
                if ("levelCompleteScore".equals(label.getId())) {
                    label.setText("Счет: " + score);
                }
            } else if (node instanceof Button && "nextLevelBtn".equals(node.getId())) {
                node.setVisible(currentLevel < 3);
            }
        }

        levelCompleteMenu.setVisible(true);
        levelCompleteMenu.toFront();
    }

    private void checkCollisions() {
        player.setOnGround(false);

        for (Platform p : platforms) {
            if (player.intersects(p)) {
                resolveCollision(p);
            }
        }
    }

    private void resolveCollision(Platform p) {
        double playerBottom = player.getY() + player.getHeight();
        double playerPrevBottom = player.getPrevY() + player.getHeight();
        double platformTop = p.getY();
        double platformBottom = p.getY() + p.getHeight();

        boolean fromAbove = playerPrevBottom <= platformTop + 5;
        boolean fromBelow = player.getPrevY() >= platformBottom - 5;
        boolean fromLeft = player.getPrevX() + player.getWidth() <= p.getX() + 5;
        boolean fromRight = player.getPrevX() >= p.getX() + p.getWidth() - 5;

        double overlapX = Math.min(
                player.getX() + player.getWidth() - p.getX(),
                p.getX() + p.getWidth() - player.getX()
        );
        double overlapY = Math.min(
                player.getY() + player.getHeight() - p.getY(),
                p.getY() + p.getHeight() - player.getY()
        );

        if (overlapX < overlapY) {
            if (fromLeft) {
                player.setX(p.getX() - player.getWidth());
            } else if (fromRight) {
                player.setX(p.getX() + p.getWidth());
            }
        } else {
            if (fromAbove && player.getVelocityY() >= 0) {
                player.landOn(platformTop - player.getHeight());
                player.setOnGround(true);
            } else if (fromBelow && player.getVelocityY() <= 0) {
                player.setY(platformBottom);
                player.setVelocityY(0);
            }
        }
    }

    private void respawnPlayer() {
        player.setX(START_X);
        player.setY(START_Y);
        player.resetVelocity();
        player.setOnGround(false);
    }

    private void gameOver() {
        paused = true;

        pauseOverlay.setVisible(true);
        pauseOverlay.toFront();

        savePlayerProgress(); // Сохраняем прогресс при Game Over

        for (javafx.scene.Node node : gameOverMenu.getChildren()) {
            if (node instanceof Label && node.getId() != null && node.getId().equals("finalScoreLabel")) {
                ((Label) node).setText("Финальный счет: " + score);
                break;
            }
        }

        gameOverMenu.setVisible(true);
        gameOverMenu.toFront();
    }

    private void render() {
        updatePlayerView();

        for (int i = 0; i < platformViews.size(); i++) {
            Rectangle view = platformViews.get(i);
            Platform p = platforms.get(i);
            view.setTranslateX(p.getX() - cameraX);
            view.setTranslateY(p.getY());
        }

        if (finishLine != null) {
            finishLine.setTranslateX(3500 - cameraX);
        }

        for (int i = 0; i < coins.size(); i++) {
            Coin coin = coins.get(i);
            Circle view = coinViews.get(i);
            view.setTranslateX(coin.getX() + coin.getSize() / 2 - cameraX);
            view.setTranslateY(coin.getY() + coin.getSize() / 2);
        }
    }

    private void updatePlayerView() {
        playerView.setTranslateX(player.getX() - cameraX);
        playerView.setTranslateY(player.getY());
    }

    private void updateUI() {
        scoreLabel.setText("Score: " + score);
        livesLabel.setText("Lives: " + player.getLives());
    }

    private boolean isPressed(KeyCode key) {
        return keys.getOrDefault(key, false);
    }
}