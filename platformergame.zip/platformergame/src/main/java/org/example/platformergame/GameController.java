package org.example.platformergame;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.InputStream;
import java.util.*;

public class GameController {

    @FXML
    private Pane gamePane;

    @FXML
    private Label scoreLabel;

    @FXML
    private Label livesLabel;

    @FXML
    private Button pauseButton;

    @FXML
    private ImageView backgroundImage;

    private Player player;
    private javafx.scene.Group playerViewGroup;
    private Rectangle playerView;
    private ImageView backgroundView;
    private final List<Platform> platforms = new ArrayList<>();
    private final List<Rectangle> platformViews = new ArrayList<>();
    private final List<FallingPlatform> fallingPlatforms = new ArrayList<>();
    private final List<Rectangle> fallingPlatformViews = new ArrayList<>();
    private final List<MovingPlatform> movingPlatforms = new ArrayList<>();
    private final List<Rectangle> movingPlatformViews = new ArrayList<>();
    private final List<Trampoline> trampolines = new ArrayList<>();
    private final List<Rectangle> trampolineViews = new ArrayList<>();
    private final List<Coin> coins = new ArrayList<>();
    private final List<Circle> coinViews = new ArrayList<>();
    private final Map<KeyCode, Boolean> keys = new HashMap<>();
    private boolean wKeyWasPressed = false;
    private AnimationTimer gameLoop;
    private int score = 0;
    private boolean paused = false;
    private VBox pauseMenu;
    private VBox gameOverMenu;
    private VBox levelCompleteMenu;
    private Rectangle pauseOverlay;
    private int currentLevel = 1;
    private double cameraX = 0;
    private Rectangle finishLine;

    private DatabaseManager db;
    private int currentPlayerId = -1;
    private String currentPlayerName = "Player1";
    private int totalDeaths = 0;
    private long levelStartTime = 0;

    private final double START_X = 50;
    private final double START_Y = 400;
    private double LEVEL_WIDTH = 2500;  // ⬅️ БЕЗ final - динамическая ширина
    private final double SCREEN_WIDTH = 900;

    private MovingPlatform playerOnMovingPlatform = null;

    @FXML
    public void initialize() {
        try {
            db = DatabaseManager.getInstance();
            currentPlayerId = db.createOrGetPlayer(currentPlayerName);
            loadPlayerProgress();
        } catch (Exception e) {
            System.err.println("⚠️ Не удалось подключиться к базе данных: " + e.getMessage());
            System.err.println("⚠️ Игра продолжит работу без сохранения прогресса");
        }

        setupBackground();
        setupPlayer();
        setupInput();
        setupPauseOverlay();
        setupPauseMenu();
        setupGameOverMenu();
        setupLevelCompleteMenu();

        javafx.application.Platform.runLater(() -> {
            gamePane.requestFocus();
            System.out.println("✅ Фокус установлен на gamePane");
        });

        startLoop();
        updateUI();
    }

    private void setupBackground() {
        try {
            String imagePath = "/org/example/platformergame/images/gameback.jpg";
            InputStream imageStream = getClass().getResourceAsStream(imagePath);

            if (imageStream == null) {
                System.err.println("❌ Не найдено изображение по пути: " + imagePath);
                throw new Exception("Изображение не найдено");
            }

            Image bgImage = new Image(imageStream);
            backgroundView = new ImageView(bgImage);

            backgroundView.setFitWidth(LEVEL_WIDTH);
            backgroundView.setFitHeight(600);
            backgroundView.setPreserveRatio(false);
            backgroundView.setMouseTransparent(true);
            backgroundView.setFocusTraversable(false);

            gamePane.getChildren().add(0, backgroundView);
            System.out.println("✅ Фон gameback.jpg загружен успешно!");

        } catch (Exception e) {
            System.err.println("⚠️ Не удалось загрузить фон: " + e.getMessage());

            Rectangle colorBg = new Rectangle(LEVEL_WIDTH, 600);

            javafx.scene.paint.Stop[] stops = new javafx.scene.paint.Stop[]{
                    new javafx.scene.paint.Stop(0, Color.rgb(135, 206, 250)),
                    new javafx.scene.paint.Stop(0.5, Color.rgb(100, 149, 237)),
                    new javafx.scene.paint.Stop(1, Color.rgb(70, 130, 180))
            };

            javafx.scene.paint.LinearGradient gradient = new javafx.scene.paint.LinearGradient(
                    0, 0, 0, 1, true, javafx.scene.paint.CycleMethod.NO_CYCLE, stops
            );

            colorBg.setFill(gradient);
            colorBg.setMouseTransparent(true);
            gamePane.getChildren().add(0, colorBg);
            backgroundView = null;

            System.out.println("⚠️ Используется запасной градиентный фон");
        }
    }

    public void setLevel(int level) {
        this.currentLevel = level;

        // ⬅️ УСТАНАВЛИВАЕМ ШИРИНУ УРОВНЯ
        if (level == 2) {
            LEVEL_WIDTH = 3100;
        } else if (level == 3) {
            LEVEL_WIDTH = 3600;
        } else {
            LEVEL_WIDTH = 2500;
        }

        loadLevel(level);
        levelStartTime = System.currentTimeMillis();
    }

    private void loadLevel(int level) {
        platforms.clear();
        platformViews.clear();
        coins.clear();
        coinViews.clear();
        fallingPlatforms.clear();
        fallingPlatformViews.clear();
        movingPlatforms.clear();
        movingPlatformViews.clear();
        trampolines.clear();
        trampolineViews.clear();
        cameraX = 0;
        finishLine = null;

        gamePane.getChildren().removeIf(node ->
                node != playerViewGroup && node != pauseOverlay && node != pauseMenu &&
                        node != gameOverMenu && node != levelCompleteMenu &&
                        node != backgroundView
        );

        // ⬅️ ПЕРЕСОЗДАЁМ ФОН С НОВОЙ ШИРИНОЙ
        if (backgroundView != null) {
            gamePane.getChildren().remove(backgroundView);
            backgroundView = null;
        }
        setupBackground();

        switch (level) {
            case 1:
                setupLevel1();
                break;
            case 2:
                setupLevel2();
                break;
            case 3:
                setupLevel3();
                break;
            default:
                setupLevel1();
        }

        levelStartTime = System.currentTimeMillis();

        if (pauseOverlay != null) pauseOverlay.toFront();
        if (pauseMenu != null) pauseMenu.toFront();
        if (gameOverMenu != null) gameOverMenu.toFront();
        if (levelCompleteMenu != null) levelCompleteMenu.toFront();
    }

    private void setupLevel1() {
        Color wallColor = Color.rgb(101, 67, 33);

        addPlatform(0, -5, 488, 340, wallColor);
        addPlatform(-2, 515, 233, 29, wallColor);
        addPlatform(468, 515, 197, 29, wallColor);
        addPlatform(488, -5, 468, 249, wallColor);
        addPlatform(841, 358, 115, 212, wallColor);
        addPlatform(1134, 190, 197, 380, wallColor);
        addPlatform(956, -5, 766, 102, wallColor);
        addPlatform(1722, -5, 115, 450, wallColor);
        addPlatform(1542, 515, 413, 29, wallColor);
        addPlatform(2303, 515, 197, 29, wallColor);

        addPlatform(241, 497, 90, 20, Color.rgb(214, 255, 0));
        addPlatform(350, 461, 90, 20, Color.rgb(214, 255, 0));
        addPlatform(1349, 205, 90, 20, Color.rgb(214, 255, 0));
        addPlatform(1443, 256, 90, 20, Color.rgb(214, 255, 0));

        addTrampoline(678, 470, 120, 30);

        addMovingPlatform(994, 466, 90, 20, MovingPlatform.Direction.VERTICAL, 170, 466, 70);
        addMovingPlatform(1592, 451, 90, 20, MovingPlatform.Direction.VERTICAL, 270, 451, 80);
        addMovingPlatform(2062, 466, 90, 20, MovingPlatform.Direction.HORIZONTAL, 2062, 2200, 90);

        addCoin(376, 430);
        addCoin(267, 460);
        addCoin(488, 460);
        addCoin(553, 460);
        addCoin(610, 460);
        addCoin(859, 326);
        addCoin(906, 326);
        addCoin(1038, 230);
        addCoin(1038, 260);
        addCoin(1038, 290);
        addCoin(1038, 340);
        addCoin(1038, 384);
        addCoin(1172, 155);
        addCoin(1222, 155);
        addCoin(1266, 155);
        addCoin(1382, 180);
        addCoin(1476, 224);
        addCoin(1625, 199);
        addCoin(1625, 253);
        addCoin(1625, 294);
        addCoin(1625, 328);
        addCoin(2026, 419);
        addCoin(2095, 419);
        addCoin(2156, 419);
        addCoin(2215, 419);

        finishLine = new Rectangle(70, 70);
        finishLine.setFill(Color.BLACK);
        finishLine.setStroke(Color.WHITE);
        finishLine.setStrokeWidth(5);
        finishLine.setTranslateX(2400);
        finishLine.setTranslateY(440);
        gamePane.getChildren().add(finishLine);
    }

    private void setupLevel2() {
        Color wallColor = Color.rgb(101, 67, 33);

        addPlatform(-1, -12, 1649, 240, wallColor);
        addPlatform(0, 510, 217, 46, wallColor);
        addPlatform(344, 510, 177, 46, wallColor);
        addPlatform(1205, 427, 128, 175, wallColor);
        addPlatform(1607, 510, 177, 46, wallColor);
        addPlatform(1780, 293, 166, 309, wallColor);
        addPlatform(2407, 510, 166, 46, wallColor);
        addPlatform(2801, 510, 266, 46, wallColor);

        addPlatform(580, 480, 110, 30, Color.rgb(201, 255, 31));
        addPlatform(1966, 200, 110, 30, Color.rgb(201, 255, 31));

        addFallingPlatform(752, 434, 110, 30, Color.BLUE);
        addFallingPlatform(1445, 450, 110, 30, Color.BLUE);
        addFallingPlatform(2126, 123, 110, 30, Color.BLUE);
        addFallingPlatform(2638, 465, 110, 30, Color.BLUE);

        addMovingPlatform(992, 384, 110, 30, MovingPlatform.Direction.HORIZONTAL, 900, 1050, 60);
        addMovingPlatform(2288, 266, 110, 30, MovingPlatform.Direction.HORIZONTAL, 2200, 2390, 50);
        addMovingPlatform(2288, 384, 110, 30, MovingPlatform.Direction.HORIZONTAL, 2200, 2390, 75);

        addTrampoline(1620, 455, 110, 50);

        addCoin(277, 450);
        addCoin(404, 470);
        addCoin(465, 470);
        addCoin(635, 437);
        addCoin(807, 400);
        addCoin(924, 345);
        addCoin(992, 345);
        addCoin(1047, 345);
        addCoin(1113, 345);
        addCoin(1269, 364);
        addCoin(1474, 408);
        addCoin(1524, 408);
        addCoin(1725, 445);
        addCoin(1724, 169);
        addCoin(1725, 225);
        addCoin(1724, 280);
        addCoin(1724, 323);
        addCoin(1724, 364);
        addCoin(1725, 407);
        addCoin(1863, 225);
        addCoin(1913, 225);
        addCoin(2021, 160);
        addCoin(2181, 78);
        addCoin(2247, 214);
        addCoin(2332, 214);
        addCoin(2418, 214);
        addCoin(2490, 214);
        addCoin(2247, 334);
        addCoin(2332, 334);
        addCoin(2407, 334);
        addCoin(2468, 334);
        addCoin(2440, 471);
        addCoin(2490, 471);
        addCoin(2542, 471);
        addCoin(2693, 426);

        finishLine = new Rectangle(70, 70);
        finishLine.setFill(Color.BLACK);
        finishLine.setStroke(Color.WHITE);
        finishLine.setStrokeWidth(5);
        finishLine.setTranslateX(2950);
        finishLine.setTranslateY(440);
        gamePane.getChildren().add(finishLine);
    }

    private void setupLevel3() {
        Color wallColor = Color.rgb(101, 67, 33); // Коричневый цвет стен

        // ========================================
        // 🟤 СТЕНЫ И ПОЛЫ (Коричневые - DODGERBLUE в прототипе)
        // ========================================

        // ⬅️ СТАРТОВАЯ ПЛАТФОРМА (чтобы игрок не падал сразу)
        addPlatform(0, 500, 130, 100, wallColor);

        // Высокая стена слева 1
        addPlatform(515, -5, 1024, 136, wallColor);

        // Высокая стена слева 1
        addPlatform(515, -5, 158, 136, wallColor);
        addPlatform(515, 273, 158, 312, wallColor);

        // Высокая стена слева 2
        addPlatform(775, -5, 158, 136, wallColor);
        addPlatform(775, 273, 158, 312, wallColor);

        // Высокая стена слева 3
        addPlatform(1024, -5, 158, 136, wallColor);
        addPlatform(1024, 273, 158, 312, wallColor);

        // Высокая стена слева 4
        addPlatform(1272, 273, 158, 312, wallColor);

        // Потолок длинный
        addPlatform(1178, -5, 746, 136, wallColor);

        // Пол средний
        addPlatform(1430, 510, 158, 36, wallColor);

        // Высокая стена справа
        addPlatform(1582, -5, 342, 282, wallColor);

        // Пол правый
        addPlatform(1938, 510, 374, 36, wallColor);

        // Стена средняя
        addPlatform(2096, 300, 176, 120, wallColor);

        // Стена верхняя правая
        addPlatform(2835, 190, 226, 136, wallColor);

        // Полы маленькие правые
        addPlatform(2399, 510, 55, 36, wallColor);
        addPlatform(2505, 510, 55, 36, wallColor);
        addPlatform(2613, 510, 55, 36, wallColor);
        addPlatform(2726, 510, 55, 36, wallColor);

        // Финальный пол
        addPlatform(3254, 510, 246, 71, wallColor);

        // ========================================
        // 🔴 ПАДАЮЩИЕ ПЛАТФОРМЫ (Красные)
        // ========================================

        addFallingPlatform(138, 480, 81, 26, Color.RED);
        addFallingPlatform(219, 434, 81, 26, Color.RED);
        addFallingPlatform(300, 377, 81, 26, Color.RED);
        addFallingPlatform(381, 324, 81, 26, Color.RED);
        addFallingPlatform(2306, 278, 81, 26, Color.RED);
        addFallingPlatform(2402, 229, 81, 26, Color.RED);
        addFallingPlatform(2505, 194, 81, 26, Color.RED);
        addFallingPlatform(3156, 306, 81, 26, Color.RED);

        // ========================================
        // 🟢 ДВИЖУЩИЕСЯ ПЛАТФОРМЫ (Зелёные) - ГОРИЗОНТАЛЬНЫЕ
        // ========================================

        addMovingPlatform(2628, 114, 110, 20, MovingPlatform.Direction.HORIZONTAL, 2550, 2750, 90);
        addMovingPlatform(2816, 479, 110, 20, MovingPlatform.Direction.HORIZONTAL, 2750, 3000, 95);
        addMovingPlatform(1688, 491, 110, 20, MovingPlatform.Direction.HORIZONTAL, 1550, 1800, 90);

        // ========================================
        // 🟡 ТРАМПЛИН (Жёлтый)
        // ========================================

        addTrampoline(2003, 480, 125, 26);

        // ========================================
        // 💰 МОНЕТЫ (Желтые шарики) - ВСЕ 97 ШТУК!
        // ========================================

        // Группа 1 - лестница слева
        addCoin(178, 450);
        addCoin(259, 393);
        addCoin(341, 340);
        addCoin(422, 276);

        // Группа 2 - над первой стеной
        addCoin(551, 237);
        addCoin(594, 237);
        addCoin(641, 237);
        addCoin(720, 202);

        // Группа 3 - над второй стеной
        addCoin(800, 237);
        addCoin(844, 237);
        addCoin(888, 237);
        addCoin(979, 202);

        // Группа 4 - над третьей стеной
        addCoin(1047, 237);
        addCoin(1103, 237);
        addCoin(1151, 237);
        addCoin(1225, 212);

        // Группа 5 - под потолком
        addCoin(1301, 222);
        addCoin(1351, 222);
        addCoin(1405, 222);
        addCoin(1509, 222);

        // Группа 6 - вертикальная линия слева от стены
        addCoin(1509, 256);
        addCoin(1509, 290);
        addCoin(1509, 330);
        addCoin(1509, 373);
        addCoin(1509, 405);
        addCoin(1509, 410);
        addCoin(1509, 479);

        // Группа 7 - в стене
        addCoin(1633, 440);
        addCoin(1681, 440);
        addCoin(1724, 440);
        addCoin(1761, 440);
        addCoin(1803, 440);
        addCoin(1847, 440);
        addCoin(1888, 440);

        // Группа 8 - над полом
        addCoin(2194, 489);
        addCoin(2235, 489);
        addCoin(2272, 489);

        // Группа 9 - справа от трамплина
        addCoin(2427, 489);
        addCoin(2533, 489);
        addCoin(2641, 489);
        addCoin(2754, 489);

        // Группа 10 - лестница вверх
        addCoin(2148, 266);
        addCoin(2194, 266);
        addCoin(2235, 266);
        addCoin(2347, 222);
        addCoin(2443, 172);
        addCoin(2546, 130);

        // Группа 11 - под зелёной платформой
        addCoin(2586, 60);
        addCoin(2641, 60);
        addCoin(2691, 60);
        addCoin(2744, 60);
        addCoin(2800, 60);
        addCoin(2855, 60);

        // Группа 12 - сетка 4x4 справа
        addCoin(2879, 60);
        addCoin(2935, 60);
        addCoin(2985, 60);
        addCoin(3029, 60);

        addCoin(2879, 102);
        addCoin(2935, 102);
        addCoin(2985, 102);
        addCoin(3029, 102);

        addCoin(2879, 130);
        addCoin(2935, 130);
        addCoin(2985, 130);
        addCoin(3029, 130);

        addCoin(2879, 160);
        addCoin(2935, 160);
        addCoin(2985, 160);
        addCoin(3029, 160);

        // Группа 13 - под второй зелёной платформой
        addCoin(2835, 430);
        addCoin(2879, 430);
        addCoin(2925, 430);
        addCoin(2975, 430);

        // Группа 14 - финальная линия
        addCoin(3019, 410);
        addCoin(3061, 410);
        addCoin(3109, 410);
        addCoin(3156, 410);
        addCoin(3207, 410);

        // Группа 15 - дополнительные
        addCoin(3099, 120);
        addCoin(3197, 228);

        // ========================================
        // 🏁 ФИНИШНАЯ ЛИНИЯ (Чёрный прямоугольник)
        // ========================================

        // layoutX=3405, layoutY=457, width=81, height=71
        finishLine = new Rectangle(70, 70);
        finishLine.setFill(Color.BLACK);
        finishLine.setStroke(Color.WHITE);
        finishLine.setStrokeWidth(5);
        finishLine.setTranslateX(3405);
        finishLine.setTranslateY(440);
        gamePane.getChildren().add(finishLine);
    }

    private void addFallingPlatform(double x, double y, double width, double height, Color color) {
        FallingPlatform fp = new FallingPlatform(x, y, width, height);
        fallingPlatforms.add(fp);
        platforms.add(fp);

        Rectangle r = new Rectangle(width, height);

        Color baseColor = Color.ORANGE;
        javafx.scene.paint.Stop[] stops = new javafx.scene.paint.Stop[]{
                new javafx.scene.paint.Stop(0, baseColor.brighter()),
                new javafx.scene.paint.Stop(0.3, baseColor),
                new javafx.scene.paint.Stop(0.7, baseColor.darker()),
                new javafx.scene.paint.Stop(1, Color.rgb(139, 69, 19))
        };

        javafx.scene.paint.LinearGradient gradient = new javafx.scene.paint.LinearGradient(
                0, 0, 0, 1, true, javafx.scene.paint.CycleMethod.NO_CYCLE, stops
        );

        r.setFill(gradient);
        r.setStroke(Color.DARKORANGE);
        r.setStrokeWidth(3);
        r.getStrokeDashArray().addAll(10.0, 5.0);

        javafx.scene.effect.DropShadow shadow = new javafx.scene.effect.DropShadow();
        shadow.setColor(Color.rgb(255, 69, 0, 0.6));
        shadow.setRadius(8);
        shadow.setOffsetX(0);
        shadow.setOffsetY(4);
        r.setEffect(shadow);

        r.setArcWidth(6);
        r.setArcHeight(6);

        r.setTranslateX(x);
        r.setTranslateY(y);
        fallingPlatformViews.add(r);
        platformViews.add(r);
        gamePane.getChildren().add(r);
    }

    private void addMovingPlatform(double x, double y, double width, double height,
                                   MovingPlatform.Direction dir, double minPos, double maxPos, double speed) {
        MovingPlatform mp = new MovingPlatform(x, y, width, height, dir, minPos, maxPos, speed);
        movingPlatforms.add(mp);
        platforms.add(mp);

        Rectangle r = new Rectangle(width, height);

        javafx.scene.paint.Stop[] stops = new javafx.scene.paint.Stop[]{
                new javafx.scene.paint.Stop(0, Color.rgb(200, 230, 255)),
                new javafx.scene.paint.Stop(0.2, Color.CYAN),
                new javafx.scene.paint.Stop(0.5, Color.rgb(0, 139, 139)),
                new javafx.scene.paint.Stop(0.8, Color.CYAN),
                new javafx.scene.paint.Stop(1, Color.rgb(100, 180, 200))
        };

        javafx.scene.paint.LinearGradient gradient = new javafx.scene.paint.LinearGradient(
                0, 0, 0, 1, true, javafx.scene.paint.CycleMethod.NO_CYCLE, stops
        );

        r.setFill(gradient);
        r.setStroke(Color.DEEPSKYBLUE);
        r.setStrokeWidth(4);

        javafx.scene.effect.Glow glow = new javafx.scene.effect.Glow();
        glow.setLevel(0.4);

        javafx.scene.effect.DropShadow shadow = new javafx.scene.effect.DropShadow();
        shadow.setColor(Color.rgb(0, 191, 255, 0.7));
        shadow.setRadius(10);
        shadow.setOffsetX(0);
        shadow.setOffsetY(0);

        glow.setInput(shadow);
        r.setEffect(glow);

        r.setArcWidth(10);
        r.setArcHeight(10);

        r.setTranslateX(x);
        r.setTranslateY(y);
        movingPlatformViews.add(r);
        platformViews.add(r);
        gamePane.getChildren().add(r);
    }

    private void addTrampoline(double x, double y, double width, double height) {
        Trampoline trampoline = new Trampoline(x, y, width, height);
        trampolines.add(trampoline);

        Rectangle r = new Rectangle(width, height);

        javafx.scene.paint.Stop[] stops = new javafx.scene.paint.Stop[]{
                new javafx.scene.paint.Stop(0, Color.YELLOW),
                new javafx.scene.paint.Stop(0.3, Color.GREENYELLOW),
                new javafx.scene.paint.Stop(0.6, Color.LIMEGREEN),
                new javafx.scene.paint.Stop(1, Color.FORESTGREEN)
        };

        javafx.scene.paint.LinearGradient gradient = new javafx.scene.paint.LinearGradient(
                0, 0, 0, 1, true, javafx.scene.paint.CycleMethod.NO_CYCLE, stops
        );

        r.setFill(gradient);
        r.setStroke(Color.DARKGREEN);
        r.setStrokeWidth(5);

        javafx.scene.effect.DropShadow shadow = new javafx.scene.effect.DropShadow();
        shadow.setColor(Color.rgb(50, 205, 50, 0.8));
        shadow.setRadius(15);
        shadow.setOffsetX(0);
        shadow.setOffsetY(0);

        javafx.scene.effect.InnerShadow innerShadow = new javafx.scene.effect.InnerShadow();
        innerShadow.setColor(Color.rgb(255, 255, 0, 0.5));
        innerShadow.setRadius(5);

        shadow.setInput(innerShadow);
        r.setEffect(shadow);

        r.setArcWidth(15);
        r.setArcHeight(15);

        r.setTranslateX(x);
        r.setTranslateY(y);
        trampolineViews.add(r);
        gamePane.getChildren().add(r);
    }

    private void addPlatform(double x, double y, double width, double height, Color color) {
        Platform p = new Platform(x, y, width, height, color);
        platforms.add(p);

        Rectangle r = new Rectangle(width, height);

        javafx.scene.paint.Stop[] stops = new javafx.scene.paint.Stop[]{
                new javafx.scene.paint.Stop(0, color.brighter()),
                new javafx.scene.paint.Stop(0.5, color),
                new javafx.scene.paint.Stop(1, color.darker())
        };

        javafx.scene.paint.LinearGradient gradient = new javafx.scene.paint.LinearGradient(
                0, 0, 0, 1, true, javafx.scene.paint.CycleMethod.NO_CYCLE, stops
        );

        r.setFill(gradient);
        r.setStroke(color.darker().darker());
        r.setStrokeWidth(3);

        javafx.scene.effect.DropShadow shadow = new javafx.scene.effect.DropShadow();
        shadow.setColor(Color.rgb(0, 0, 0, 0.5));
        shadow.setRadius(5);
        shadow.setOffsetX(2);
        shadow.setOffsetY(3);
        r.setEffect(shadow);

        r.setArcWidth(8);
        r.setArcHeight(8);

        r.setTranslateX(x);
        r.setTranslateY(y);
        platformViews.add(r);
        gamePane.getChildren().add(r);
    }

    private void addCoin(double x, double y) {
        Coin coin = new Coin(x, y, 20);
        coins.add(coin);

        Circle circle = new Circle(coin.getSize() / 2);

        javafx.scene.paint.Stop[] stops = new javafx.scene.paint.Stop[]{
                new javafx.scene.paint.Stop(0, Color.rgb(255, 255, 150)),
                new javafx.scene.paint.Stop(0.5, Color.GOLD),
                new javafx.scene.paint.Stop(0.8, Color.rgb(255, 215, 0)),
                new javafx.scene.paint.Stop(1, Color.rgb(218, 165, 32))
        };

        javafx.scene.paint.RadialGradient gradient = new javafx.scene.paint.RadialGradient(
                0, 0, 0.5, 0.5, 0.5, true,
                javafx.scene.paint.CycleMethod.NO_CYCLE,
                stops
        );

        circle.setFill(gradient);
        circle.setStroke(Color.DARKORANGE);
        circle.setStrokeWidth(3);

        javafx.scene.effect.DropShadow shadow = new javafx.scene.effect.DropShadow();
        shadow.setColor(Color.rgb(255, 215, 0, 0.9));
        shadow.setRadius(12);
        shadow.setOffsetX(0);
        shadow.setOffsetY(0);
        circle.setEffect(shadow);

        circle.setTranslateX(coin.getX() + coin.getSize() / 2);
        circle.setTranslateY(coin.getY() + coin.getSize() / 2);

        javafx.animation.RotateTransition rotate = new javafx.animation.RotateTransition();
        rotate.setNode(circle);
        rotate.setDuration(javafx.util.Duration.seconds(2));
        rotate.setFromAngle(0);
        rotate.setToAngle(360);
        rotate.setCycleCount(javafx.animation.Animation.INDEFINITE);
        rotate.setInterpolator(javafx.animation.Interpolator.LINEAR);
        rotate.play();

        javafx.animation.ScaleTransition scale = new javafx.animation.ScaleTransition();
        scale.setNode(circle);
        scale.setDuration(javafx.util.Duration.seconds(1));
        scale.setFromX(1.0);
        scale.setFromY(1.0);
        scale.setToX(1.2);
        scale.setToY(1.2);
        scale.setCycleCount(javafx.animation.Animation.INDEFINITE);
        scale.setAutoReverse(true);
        scale.play();

        coinViews.add(circle);
        gamePane.getChildren().add(circle);
    }

    private void loadPlayerProgress() {
        if (currentPlayerId == -1 || db == null) return;

        try {
            DatabaseManager.PlayerProgress progress = db.loadProgress(currentPlayerId);
            if (progress != null) {
                currentLevel = progress.currentLevel;
                totalDeaths = progress.totalDeaths;
                System.out.println("📊 Прогресс загружен из БД: " + progress);
            }
        } catch (Exception e) {
            System.err.println("⚠️ Ошибка загрузки прогресса: " + e.getMessage());
        }
    }

    private void savePlayerProgress() {
        if (currentPlayerId == -1 || db == null) return;

        try {
            String playerName = db.getPlayerName(currentPlayerId);
            DatabaseManager.LevelStatistics stats = db.getLevelStatistics(playerName, currentLevel);

            double bestTime = 0.0;
            if (stats != null && stats.attempts > 0) {
                bestTime = stats.bestTime;
            }

            db.saveProgress(currentPlayerId, currentLevel, totalDeaths, bestTime);
        } catch (Exception e) {
            System.err.println("⚠️ Ошибка сохранения прогресса: " + e.getMessage());
        }
    }

    private void saveRecord() {
        if (currentPlayerId == -1 || db == null) return;

        try {
            double time = (System.currentTimeMillis() - levelStartTime) / 1000.0;
            String playerName = db.getPlayerName(currentPlayerId);
            db.saveRecord(playerName, currentLevel, time, score);

            System.out.println("⏱️ Время прохождения уровня " + currentLevel + ": " + String.format("%.1f", time) + " сек");
        } catch (Exception e) {
            System.err.println("⚠️ Ошибка сохранения рекорда: " + e.getMessage());
        }
    }

    private void updateFallingPlatforms(double dt) {
        for (int i = fallingPlatforms.size() - 1; i >= 0; i--) {
            FallingPlatform fp = fallingPlatforms.get(i);

            double playerBottom = player.getY() + player.getHeight();
            double platformTop = fp.getY();

            boolean onPlatform = player.getX() + player.getWidth() > fp.getX() &&
                    player.getX() < fp.getX() + fp.getWidth() &&
                    playerBottom >= platformTop &&
                    playerBottom <= platformTop + 10 &&
                    player.getVelocityY() >= 0;

            if (onPlatform && player.isOnGround()) {
                fp.activate();
            }

            fp.update(dt);

            Rectangle view = fallingPlatformViews.get(i);
            double shakeIntensity = fp.getShakeIntensity();

            if (shakeIntensity > 0 && !fp.isFalling()) {
                double shakeX = (Math.random() - 0.5) * shakeIntensity * 10;
                double shakeY = (Math.random() - 0.5) * shakeIntensity * 5;
                view.setTranslateX(fp.getX() - cameraX + shakeX);
                view.setTranslateY(fp.getY() + shakeY);

                Color baseColor = Color.ORANGE;
                Color dangerColor = Color.RED;
                view.setFill(baseColor.interpolate(dangerColor, shakeIntensity));
            } else if (fp.isFalling()) {
                view.setTranslateX(fp.getX() - cameraX);
                view.setTranslateY(fp.getY());
            }

            if (fp.shouldRemove()) {
                fallingPlatforms.remove(i);
                fallingPlatformViews.remove(i);
                platforms.remove(fp);
                platformViews.remove(view);
                gamePane.getChildren().remove(view);
            }
        }
    }

    private void updateMovingPlatforms(double dt) {
        playerOnMovingPlatform = null;

        for (int i = 0; i < movingPlatforms.size(); i++) {
            MovingPlatform mp = movingPlatforms.get(i);

            double playerBottom = player.getY() + player.getHeight();
            double platformTop = mp.getY();

            boolean onPlatform = player.getX() + player.getWidth() > mp.getX() &&
                    player.getX() < mp.getX() + mp.getWidth() &&
                    playerBottom >= platformTop &&
                    playerBottom <= platformTop + 10 &&
                    player.getVelocityY() >= 0 &&
                    player.isOnGround();

            if (onPlatform) {
                playerOnMovingPlatform = mp;
            }

            mp.update(dt);
        }

        if (playerOnMovingPlatform != null) {
            if (playerOnMovingPlatform.getDirection() == MovingPlatform.Direction.HORIZONTAL) {
                double platformVelocityX = playerOnMovingPlatform.getVelocityX();
                player.setX(player.getX() + platformVelocityX * dt);
            }
        }
    }

    private void updateTrampolines(double dt) {
        for (int i = 0; i < trampolines.size(); i++) {
            Trampoline trampoline = trampolines.get(i);
            trampoline.update(dt);

            if (trampoline.shouldBounce(player)) {
                player.setVelocityY(trampoline.getBounceForce());
                player.setOnGround(false);
                trampoline.bounce();
                System.out.println("🎪 BOUNCE!");
            }

            Rectangle view = trampolineViews.get(i);
            double compression = trampoline.getCompression();
            if (compression > 0) {
                view.setTranslateY(trampoline.getY() + compression * 5);
                view.setHeight(20 - compression * 5);
            } else {
                view.setTranslateY(trampoline.getY());
                view.setHeight(20);
            }
        }
    }

    private void loadNextLevel() {
        levelCompleteMenu.setVisible(false);
        pauseOverlay.setVisible(false);

        if (currentLevel < 3) {
            currentLevel++;
            player.reset(START_X, START_Y);
            score = 0;
            setLevel(currentLevel);  // ⬅️ ИСПОЛЬЗУЕМ setLevel вместо loadLevel
            paused = false;
            updateUI();

            savePlayerProgress();
        } else {
            showAllLevelsComplete();
        }
    }

    private void showAllLevelsComplete() {
        levelCompleteMenu.setVisible(false);
        pauseOverlay.setVisible(true);
        pauseOverlay.toFront();

        VBox allCompleteMenu = new VBox(30);
        allCompleteMenu.setStyle("-fx-background-color: rgba(255, 215, 0, 0.95); -fx-padding: 50; -fx-alignment: center; -fx-border-color: gold; -fx-border-width: 5;");
        allCompleteMenu.setPrefSize(450, 350);
        allCompleteMenu.setLayoutX(225);
        allCompleteMenu.setLayoutY(125);

        Label congratsLabel = new Label("🎉 ПОЗДРАВЛЯЕМ! 🎉");
        congratsLabel.setStyle("-fx-font-size: 42; -fx-text-fill: #FF6B00; -fx-font-weight: bold;");

        Label messageLabel = new Label("Вы прошли все уровни!");
        messageLabel.setStyle("-fx-font-size: 24; -fx-text-fill: #8B4513;");

        Label scoreLabel = new Label("FINAL SCORE: " + score);
        scoreLabel.setStyle("-fx-font-size: 20; -fx-text-fill: #8B4513;");

        Button menuBtn = new Button("🏠 В меню");
        menuBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 280; -fx-pref-height: 50; -fx-background-color: #3498DB; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        menuBtn.setOnAction(e -> {
            gamePane.getChildren().remove(allCompleteMenu);
            returnToMenu();
        });

        Button exitBtn = new Button("✕ Выход");
        exitBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 280; -fx-pref-height: 50; -fx-background-color: #E74C3C; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        exitBtn.setOnAction(e -> System.exit(0));

        allCompleteMenu.getChildren().addAll(congratsLabel, messageLabel, scoreLabel, menuBtn, exitBtn);
        gamePane.getChildren().add(allCompleteMenu);
        allCompleteMenu.toFront();

        savePlayerProgress();
    }

    private void setupPlayer() {
        player = new Player(START_X, START_Y, 40, 40);

        javafx.scene.Group astronaut = new javafx.scene.Group();

        playerView = new Rectangle(player.getWidth(), player.getHeight());

        javafx.scene.paint.Stop[] bodyStops = new javafx.scene.paint.Stop[]{
                new javafx.scene.paint.Stop(0, Color.rgb(255, 255, 255)),
                new javafx.scene.paint.Stop(0.5, Color.rgb(240, 240, 245)),
                new javafx.scene.paint.Stop(1, Color.rgb(220, 220, 230))
        };

        javafx.scene.paint.LinearGradient bodyGradient = new javafx.scene.paint.LinearGradient(
                0, 0, 0, 1, true, javafx.scene.paint.CycleMethod.NO_CYCLE, bodyStops
        );

        playerView.setFill(bodyGradient);
        playerView.setStroke(Color.rgb(180, 180, 190));
        playerView.setStrokeWidth(2);
        playerView.setArcWidth(8);
        playerView.setArcHeight(8);

        javafx.scene.effect.DropShadow bodyShadow = new javafx.scene.effect.DropShadow();
        bodyShadow.setColor(Color.rgb(0, 0, 0, 0.3));
        bodyShadow.setRadius(5);
        bodyShadow.setOffsetY(2);
        playerView.setEffect(bodyShadow);

        Rectangle visor = new Rectangle();
        visor.setWidth(player.getWidth() - 8);
        visor.setHeight(10);
        visor.setX(4);
        visor.setY(12);
        visor.setFill(Color.rgb(20, 20, 25));
        visor.setArcWidth(3);
        visor.setArcHeight(3);

        astronaut.getChildren().addAll(playerView, visor);
        gamePane.getChildren().add(astronaut);
        playerViewGroup = astronaut;

        updatePlayerView();
    }

    private void setupInput() {
        gamePane.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                newScene.setOnKeyPressed(e -> {
                    keys.put(e.getCode(), true);
                    if (e.getCode() == KeyCode.ESCAPE) {
                        togglePause();
                    }
                });
                newScene.setOnKeyReleased(e -> {
                    keys.put(e.getCode(), false);
                });

                javafx.application.Platform.runLater(() -> {
                    gamePane.requestFocus();
                });
            }
        });

        gamePane.setFocusTraversable(true);
    }

    private void setupPauseOverlay() {
        pauseOverlay = new Rectangle(900, 600);
        pauseOverlay.setFill(Color.rgb(0, 0, 0, 0.7));
        pauseOverlay.setVisible(false);
        gamePane.getChildren().add(pauseOverlay);
    }

    private void setupPauseMenu() {
        pauseMenu = new VBox(20);
        pauseMenu.setStyle("-fx-background-color: rgba(0, 0, 0, 0.95); -fx-padding: 40; -fx-alignment: center; -fx-border-color: white; -fx-border-width: 3;");
        pauseMenu.setPrefSize(300, 250);
        pauseMenu.setLayoutX(300);
        pauseMenu.setLayoutY(175);
        pauseMenu.setVisible(false);

        Label pauseLabel = new Label("PAUSE");
        pauseLabel.setStyle("-fx-font-size: 32; -fx-text-fill: white; -fx-font-weight: bold;");

        Button resumeBtn = new Button("RESUME");
        resumeBtn.setStyle("-fx-font-size: 16; -fx-pref-width: 200;");
        resumeBtn.setOnAction(e -> togglePause());

        Button menuBtn = new Button("MENU");
        menuBtn.setStyle("-fx-font-size: 16; -fx-pref-width: 200;");
        menuBtn.setOnAction(e -> returnToMenu());

        Button exitBtn = new Button("EXIT");
        exitBtn.setStyle("-fx-font-size: 16; -fx-pref-width: 200;");
        exitBtn.setOnAction(e -> System.exit(0));

        pauseMenu.getChildren().addAll(pauseLabel, resumeBtn, menuBtn, exitBtn);
        gamePane.getChildren().add(pauseMenu);
    }

    private void setupGameOverMenu() {
        gameOverMenu = new VBox(25);
        gameOverMenu.setStyle("-fx-background-color: rgba(139, 0, 0, 0.9); -fx-padding: 50; -fx-alignment: center; -fx-border-color: red; -fx-border-width: 3;");
        gameOverMenu.setPrefSize(400, 350);
        gameOverMenu.setLayoutX(250);
        gameOverMenu.setLayoutY(125);
        gameOverMenu.setVisible(false);

        Label gameOverLabel = new Label("GAME OVER");
        gameOverLabel.setStyle("-fx-font-size: 48; -fx-text-fill: #FF6B6B; -fx-font-weight: bold;");

        Label finalScoreLabel = new Label("FINAL SCORE: 0");
        finalScoreLabel.setStyle("-fx-font-size: 24; -fx-text-fill: white;");
        finalScoreLabel.setId("finalScoreLabel");

        Button restartBtn = new Button("🔄 PLAY AGAIN");
        restartBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 250; -fx-pref-height: 50; -fx-background-color: #27AE60; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        restartBtn.setOnAction(e -> restartGame());

        Button menuBtn = new Button("🏠 MENU");
        menuBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 250; -fx-pref-height: 50; -fx-background-color: #3498DB; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        menuBtn.setOnAction(e -> returnToMenu());

        Button exitBtn = new Button("✕ EXIT");
        exitBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 250; -fx-pref-height: 50; -fx-background-color: #E74C3C; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        exitBtn.setOnAction(e -> System.exit(0));

        gameOverMenu.getChildren().addAll(gameOverLabel, finalScoreLabel, restartBtn, menuBtn, exitBtn);
        gamePane.getChildren().add(gameOverMenu);
    }

    private void setupLevelCompleteMenu() {
        levelCompleteMenu = new VBox(25);
        levelCompleteMenu.setStyle("-fx-background-color: rgba(0, 139, 0, 0.9); -fx-padding: 50; -fx-alignment: center; -fx-border-color: green; -fx-border-width: 3;");
        levelCompleteMenu.setPrefSize(400, 400);
        levelCompleteMenu.setLayoutX(250);
        levelCompleteMenu.setLayoutY(100);
        levelCompleteMenu.setVisible(false);

        Label completeLabel = new Label("FINISHED!");
        completeLabel.setStyle("-fx-font-size: 40; -fx-text-fill: #90EE90; -fx-font-weight: bold;");

        Label scoreLabel = new Label("SCORE: 0");
        scoreLabel.setStyle("-fx-font-size: 24; -fx-text-fill: white;");
        scoreLabel.setId("levelCompleteScore");

        Label coinsLabel = new Label("LEVEL COINS:");
        coinsLabel.setStyle("-fx-font-size: 20; -fx-text-fill: white;");
        coinsLabel.setId("levelCompleteCoins");

        Button nextBtn = new Button("➡️ NEXT LEVEL");
        nextBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 280; -fx-pref-height: 50; -fx-background-color: #27AE60; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        nextBtn.setOnAction(e -> loadNextLevel());
        nextBtn.setId("nextLevelBtn");

        Button retryBtn = new Button("🔄 RETRY");
        retryBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 280; -fx-pref-height: 50; -fx-background-color: #F39C12; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        retryBtn.setOnAction(e -> restartGame());

        Button menuBtn = new Button("🏠 MENU");
        menuBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 280; -fx-pref-height: 50; -fx-background-color: #3498DB; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        menuBtn.setOnAction(e -> returnToMenu());

        levelCompleteMenu.getChildren().addAll(completeLabel, scoreLabel, coinsLabel, nextBtn, retryBtn, menuBtn);
        gamePane.getChildren().add(levelCompleteMenu);
    }

    @FXML
    private void onPause() {
        togglePause();
    }

    private void togglePause() {
        paused = !paused;
        pauseOverlay.setVisible(paused);
        pauseMenu.setVisible(paused);

        if (paused) {
            pauseButton.setText("RESUME");
            pauseOverlay.toFront();
            pauseMenu.toFront();
            pauseButton.toFront();
        } else {
            pauseButton.setText("PAUSE");
        }
    }

    private void returnToMenu() {
        try {
            savePlayerProgress();

            gameLoop.stop();
            Stage stage = (Stage) gamePane.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
            Parent root = loader.load();
            MenuController controller = loader.getController();
            controller.setStage(stage);
            stage.setScene(new Scene(root, 900, 600));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onReset() {
        restartGame();
    }

    private void restartGame() {
        gameOverMenu.setVisible(false);
        levelCompleteMenu.setVisible(false);
        pauseOverlay.setVisible(false);

        player.reset(START_X, START_Y);
        score = 0;
        cameraX = 0;

        setLevel(currentLevel);  // ⬅️ ИСПОЛЬЗУЕМ setLevel

        paused = false;
        pauseButton.setText("PAUSE");

        updatePlayerView();
        updateUI();

        if (pauseOverlay != null) pauseOverlay.toFront();
        if (pauseMenu != null) pauseMenu.toFront();
        if (gameOverMenu != null) gameOverMenu.toFront();
        if (levelCompleteMenu != null) levelCompleteMenu.toFront();

        if (playerViewGroup != null) {
            playerViewGroup.setVisible(true);
        }
    }

    private void startLoop() {
        gameLoop = new AnimationTimer() {
            private long last = 0;

            @Override
            public void handle(long now) {
                if (last == 0) last = now;
                double delta = (now - last) / 1_000_000_000.0;

                if (!paused && !player.isDead()) {
                    update(delta);
                    render();
                }

                last = now;
            }
        };
        gameLoop.start();
    }

    private void update(double dt) {
        player.savePrevPosition();

        if (isPressed(KeyCode.A)) {
            player.moveX(-220 * dt);
        }
        if (isPressed(KeyCode.D)) {
            player.moveX(220 * dt);
        }

        boolean wKeyPressed = isPressed(KeyCode.W);
        if (wKeyPressed && !wKeyWasPressed) {
            player.jump();
        }
        wKeyWasPressed = wKeyPressed;

        player.applyGravity(dt);

        checkCollisions();

        updateFallingPlatforms(dt);
        updateMovingPlatforms(dt);
        updateTrampolines(dt);

        if (player.getX() < 0) player.setX(0);
        if (player.getX() + player.getWidth() > LEVEL_WIDTH) {
            player.setX(LEVEL_WIDTH - player.getWidth());
        }

        double TOP_BOUNDARY = 13;
        if (player.getY() < TOP_BOUNDARY) {
            player.setY(TOP_BOUNDARY);
            player.setVelocityY(0);
        }

        updateCamera();

        if (player.getY() > 600) {
            player.loseLife();
            totalDeaths++;

            if (!player.isDead()) {
                respawnPlayer();
            } else {
                gameOver();
            }
        }

        for (int i = 0; i < coins.size(); i++) {
            Coin coin = coins.get(i);
            if (!coin.isCollected() && coin.intersects(player)) {
                coin.collect();
                coinViews.get(i).setVisible(false);
                score += 10;
            }
        }

        // ⬅️ ИСПРАВЛЕНА ПРОВЕРКА ФИНИША
        // Финишная линия
        if (finishLine != null) {
            double finishX, finishY, finishW, finishH;

            if (currentLevel == 2) {
                finishX = 2889;
                finishY = 476;
                finishW = 97;
                finishH = 78;
            } else if (currentLevel == 3) {
                finishX = 3405;  // ⬅️ ОБНОВЛЕНО
                finishY = 457;   // ⬅️ ОБНОВЛЕНО
                finishW = 81;    // ⬅️ ОБНОВЛЕНО
                finishH = 71;    // ⬅️ ОБНОВЛЕНО
            } else {
                finishX = 2400;
                finishY = 395;
                finishW = 80;
                finishH = 120;
            }

            if (player.getX() + player.getWidth() > finishX &&
                    player.getX() < finishX + finishW &&
                    player.getY() + player.getHeight() > finishY &&
                    player.getY() < finishY + finishH) {
                levelComplete();
            }
        }
        updateUI();
    }

    private void updateCamera() {
        double targetCameraX = player.getX() - SCREEN_WIDTH / 2;

        if (targetCameraX < 0) targetCameraX = 0;
        if (targetCameraX > LEVEL_WIDTH - SCREEN_WIDTH) {
            targetCameraX = LEVEL_WIDTH - SCREEN_WIDTH;
        }

        cameraX = targetCameraX;
    }

    private void levelComplete() {
        paused = true;

        pauseOverlay.setVisible(true);
        pauseOverlay.toFront();

        saveRecord();
        savePlayerProgress();

        for (javafx.scene.Node node : levelCompleteMenu.getChildren()) {
            if (node instanceof Label) {
                Label label = (Label) node;
                if ("levelCompleteScore".equals(label.getId())) {
                    label.setText("SCORE: " + score);
                }
            } else if (node instanceof Button && "nextLevelBtn".equals(node.getId())) {
                node.setVisible(currentLevel < 3);
            }
        }

        levelCompleteMenu.setVisible(true);
        levelCompleteMenu.toFront();
    }

    private void checkCollisions() {
        player.setOnGround(false);

        for (Platform p : platforms) {
            if (player.intersects(p)) {
                resolveCollision(p);
            }
        }
    }

    private void resolveCollision(Platform p) {
        double playerBottom = player.getY() + player.getHeight();
        double playerPrevBottom = player.getPrevY() + player.getHeight();
        double platformTop = p.getY();
        double platformBottom = p.getY() + p.getHeight();

        boolean fromAbove = playerPrevBottom <= platformTop + 5;
        boolean fromBelow = player.getPrevY() >= platformBottom - 5;
        boolean fromLeft = player.getPrevX() + player.getWidth() <= p.getX() + 5;
        boolean fromRight = player.getPrevX() >= p.getX() + p.getWidth() - 5;

        double overlapX = Math.min(
                player.getX() + player.getWidth() - p.getX(),
                p.getX() + p.getWidth() - player.getX()
        );
        double overlapY = Math.min(
                player.getY() + player.getHeight() - p.getY(),
                p.getY() + p.getHeight() - player.getY()
        );

        if (overlapX < overlapY) {
            if (fromLeft) {
                player.setX(p.getX() - player.getWidth());
            } else if (fromRight) {
                player.setX(p.getX() + p.getWidth());
            }
        } else {
            if (fromAbove && player.getVelocityY() >= 0) {
                player.landOn(platformTop - player.getHeight());
                player.setOnGround(true);
            } else if (fromBelow && player.getVelocityY() <= 0) {
                player.setY(platformBottom);
                player.setVelocityY(0);
            }
        }
    }

    private void respawnPlayer() {
        player.setX(START_X);
        player.setY(START_Y);
        player.resetVelocity();
        player.setOnGround(false);
    }

    private void gameOver() {
        paused = true;

        pauseOverlay.setVisible(true);
        pauseOverlay.toFront();

        savePlayerProgress();

        for (javafx.scene.Node node : gameOverMenu.getChildren()) {
            if (node instanceof Label && node.getId() != null && node.getId().equals("finalScoreLabel")) {
                ((Label) node).setText("FINAL SCORE: " + score);
                break;
            }
        }

        gameOverMenu.setVisible(true);
        gameOverMenu.toFront();
    }

    private void render() {
        updatePlayerView();

        if (backgroundView != null) {
            try {
                backgroundView.setTranslateX(-cameraX * 0.5);
            } catch (Exception e) {
                System.err.println("⚠️ Ошибка при обновлении фона: " + e.getMessage());
            }
        }

        for (int i = 0; i < platformViews.size(); i++) {
            Rectangle view = platformViews.get(i);
            Platform p = platforms.get(i);

            boolean isFallingPlatform = fallingPlatforms.contains(p);

            if (!isFallingPlatform) {
                view.setTranslateX(p.getX() - cameraX);
                view.setTranslateY(p.getY());
            } else {
                FallingPlatform fp = (FallingPlatform) p;
                int fpIndex = fallingPlatforms.indexOf(fp);
                Rectangle fpView = fallingPlatformViews.get(fpIndex);

                if (fp.getShakeIntensity() == 0 || fp.isFalling()) {
                    fpView.setTranslateX(fp.getX() - cameraX);
                    fpView.setTranslateY(fp.getY());
                }
            }
        }

        for (int i = 0; i < trampolineViews.size(); i++) {
            Rectangle view = trampolineViews.get(i);
            Trampoline t = trampolines.get(i);
            view.setTranslateX(t.getX() - cameraX);
        }

        // ⬅️ ИСПРАВЛЕНО ОТОБРАЖЕНИЕ ФИНИША
        // Финиш
        if (finishLine != null) {
            if (currentLevel == 2) {
                finishLine.setTranslateX(2889 - cameraX);
            } else if (currentLevel == 3) {
                finishLine.setTranslateX(3405 - cameraX);  // ⬅️ ОБНОВЛЕНО
            } else {
                finishLine.setTranslateX(2400 - cameraX);
            }
        }

        for (int i = 0; i < coins.size(); i++) {
            Coin coin = coins.get(i);
            Circle view = coinViews.get(i);
            view.setTranslateX(coin.getX() + coin.getSize() / 2 - cameraX);
            view.setTranslateY(coin.getY() + coin.getSize() / 2);
        }
    }

    private void updatePlayerView() {
        if (playerViewGroup != null) {
            playerViewGroup.setTranslateX(player.getX() - cameraX);
            playerViewGroup.setTranslateY(player.getY());
        }
    }

    private void updateUI() {
        scoreLabel.setText("Score: " + score);
        livesLabel.setText("Lives: " + player.getLives());
    }

    private boolean isPressed(KeyCode key) {
        return keys.getOrDefault(key, false);
    }
}