package org.example.platformergame;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.util.*;

public class GameController {

    @FXML
    private Pane gamePane;

    @FXML
    private Label scoreLabel;

    @FXML
    private Label livesLabel;

    @FXML
    private Button pauseButton;

    private Player player;
    private Rectangle playerView;
    private final List<Platform> platforms = new ArrayList<>();
    private final List<Rectangle> platformViews = new ArrayList<>(); // Визуальные элементы платформ
    private final List<Coin> coins = new ArrayList<>();
    private final List<Circle> coinViews = new ArrayList<>();
    private final List<Enemy> enemies = new ArrayList<>();
    private final List<Rectangle> enemyViews = new ArrayList<>();
    private final Map<KeyCode, Boolean> keys = new HashMap<>();
    private boolean wKeyWasPressed = false; // Для отслеживания нажатия W
    private AnimationTimer gameLoop;
    private int score = 0;
    private boolean paused = false;
    private VBox pauseMenu;
    private VBox gameOverMenu;
    private VBox levelCompleteMenu;
    private Rectangle pauseOverlay; // Затемнение при паузе
    private int currentLevel = 1;
    private int totalCoins = 0; // Общее количество монет на уровне
    private double cameraX = 0; // Позиция камеры для прокрутки
    private Rectangle finishLine; // Финишная линия

    private final double START_X = 50;
    private final double START_Y = 400;
    private final double LEVEL_WIDTH = 3600; // Длина уровня
    private final double SCREEN_WIDTH = 900;

    @FXML
    public void initialize() {
        setupPlayer();
        setupInput();
        setupPauseOverlay();
        setupPauseMenu();
        setupGameOverMenu();
        setupLevelCompleteMenu();
        startLoop();
        updateUI();
    }

    public void setLevel(int level) {
        this.currentLevel = level;
        loadLevel(level);
    }

    private void loadLevel(int level) {
        // Очищаем предыдущие объекты
        platforms.clear();
        platformViews.clear();
        coins.clear();
        coinViews.clear();
        enemies.clear();
        enemyViews.clear();
        cameraX = 0;
        finishLine = null;

        // Удаляем визуальные элементы (кроме игрока и меню)
        gamePane.getChildren().removeIf(node ->
                node != playerView && node != pauseOverlay && node != pauseMenu &&
                        node != gameOverMenu && node != levelCompleteMenu
        );

        // Загружаем уровень
        switch (level) {
            case 1:
                setupScrollingLevel();
                break;
            case 2:
                setupLevel2();
                break;
            case 3:
                setupLevel3();
                break;
            default:
                setupScrollingLevel();
        }

        totalCoins = coins.size();
    }

    // =============== ДЛИННЫЙ УРОВЕНЬ С ПРОКРУТКОЙ (УРОВЕНЬ 1) ===============

    private void setupScrollingLevel() {
        // ===== ЗЕМЛЯ =====
        addPlatform(0, 520, 3600, 80, Color.BROWN.darker()); // Длинная земля

        // ===== НАЧАЛО (0-600) =====
        addPlatform(150, 450, 120, 20, Color.GREEN.darker());
        addPlatform(320, 400, 100, 20, Color.GREEN.darker());
        addCoin(180, 420);
        addCoin(350, 370);
        addCoin(200, 490);
        addEnemy(160, 422, 150, 250, 60);

        // ===== ПЕРВАЯ СЕКЦИЯ (600-1200) - Лестница вверх =====
        addPlatform(650, 450, 100, 20, Color.LIGHTBLUE.darker());
        addPlatform(800, 400, 100, 20, Color.LIGHTBLUE.darker());
        addPlatform(950, 350, 100, 20, Color.LIGHTBLUE.darker());
        addPlatform(1100, 300, 100, 20, Color.LIGHTBLUE.darker());
        addCoin(680, 420);
        addCoin(830, 370);
        addCoin(980, 320);
        addCoin(1130, 270);
        addEnemy(660, 422, 650, 730, 65);
        addEnemy(810, 372, 800, 880, 70);
        addEnemy(1110, 272, 1100, 1180, 75);

        // ===== ВТОРАЯ СЕКЦИЯ (1200-1800) - Высокие платформы =====
        addPlatform(1250, 250, 120, 20, Color.PURPLE.darker());
        addPlatform(1450, 200, 100, 20, Color.PURPLE.darker());
        addPlatform(1600, 250, 120, 20, Color.PURPLE.darker());
        addCoin(1280, 220);
        addCoin(1480, 170);
        addCoin(1630, 220);
        addCoin(1350, 490);
        addCoin(1550, 490);
        addEnemy(1260, 222, 1250, 1350, 80);
        addEnemy(1300, 492, 1250, 1450, 70);
        addEnemy(1610, 222, 1600, 1700, 85);

        // ===== ТРЕТЬЯ СЕКЦИЯ (1800-2400) - Пропасти и прыжки =====
        addPlatform(1900, 450, 80, 20, Color.ORANGE.darker());
        addPlatform(2050, 400, 80, 20, Color.ORANGE.darker());
        addPlatform(2200, 450, 80, 20, Color.ORANGE.darker());
        addPlatform(2350, 380, 100, 20, Color.ORANGE.darker());
        addCoin(1920, 420);
        addCoin(2070, 370);
        addCoin(2220, 420);
        addCoin(2380, 350);
        addCoin(2000, 490);
        addEnemy(1910, 422, 1900, 1960, 50);
        addEnemy(2060, 372, 2050, 2110, 55);
        addEnemy(2210, 422, 2200, 2260, 50);

        // ===== ЧЕТВЕРТАЯ СЕКЦИЯ (2400-3000) - Сложная секция =====
        addPlatform(2500, 350, 100, 20, Color.RED.darker());
        addPlatform(2650, 300, 80, 20, Color.RED.darker());
        addPlatform(2780, 250, 80, 20, Color.RED.darker());
        addPlatform(2900, 200, 100, 20, Color.RED.darker());
        addPlatform(2700, 450, 100, 20, Color.RED.darker());
        addCoin(2530, 320);
        addCoin(2670, 270);
        addCoin(2800, 220);
        addCoin(2930, 170);
        addCoin(2730, 420);
        addCoin(2600, 490);
        addCoin(2800, 490);
        addEnemy(2510, 322, 2500, 2580, 90);
        addEnemy(2660, 272, 2650, 2710, 85);
        addEnemy(2710, 422, 2700, 2780, 70);
        addEnemy(2910, 172, 2900, 2980, 95);

        // ===== ФИНАЛЬНАЯ СЕКЦИЯ (3000-3600) - Спуск к финишу =====
        addPlatform(3050, 350, 100, 20, Color.GOLD.darker());
        addPlatform(3200, 400, 120, 20, Color.GOLD.darker());
        addPlatform(3350, 450, 100, 20, Color.GOLD.darker());
        addCoin(3080, 320);
        addCoin(3230, 370);
        addCoin(3380, 420);
        addCoin(3150, 490);
        addCoin(3300, 490);
        addEnemy(3060, 322, 3050, 3130, 75);
        addEnemy(3210, 372, 3200, 3300, 80);

        // ===== ФИНИШНАЯ ЛИНИЯ =====
        finishLine = new Rectangle(50, 150);
        finishLine.setFill(Color.rgb(255, 215, 0, 0.7));
        finishLine.setStroke(Color.GOLD);
        finishLine.setStrokeWidth(3);
        finishLine.setTranslateX(3500);
        finishLine.setTranslateY(370);
        gamePane.getChildren().add(finishLine);
    }

    // =============== ОБЫЧНЫЕ УРОВНИ (2 и 3) ===============

    private void setupLevel2() {
        // УРОВЕНЬ 2 - СРЕДНИЙ (больше врагов, узкие платформы)

        // Платформы
        addPlatform(0, 520, 900, 80, Color.BROWN.darker());
        addPlatform(100, 440, 100, 20, Color.ORANGE.darker());
        addPlatform(280, 380, 100, 20, Color.ORANGE.darker());
        addPlatform(460, 320, 100, 20, Color.ORANGE.darker());
        addPlatform(640, 260, 100, 20, Color.ORANGE.darker());
        addPlatform(460, 200, 100, 20, Color.ORANGE.darker());
        addPlatform(280, 140, 100, 20, Color.ORANGE.darker());
        addPlatform(100, 80, 100, 20, Color.ORANGE.darker());

        // Монеты
        addCoin(130, 410);
        addCoin(310, 350);
        addCoin(490, 290);
        addCoin(670, 230);
        addCoin(490, 170);
        addCoin(310, 110);
        addCoin(130, 50);
        addCoin(400, 490);
        addCoin(600, 490);

        // Враги (средне)
        addEnemy(110, 412, 100, 180, 60);
        addEnemy(290, 352, 280, 360, 65);
        addEnemy(470, 292, 460, 540, 70);
        addEnemy(650, 232, 640, 720, 55);
    }

    // =============== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ===============

    private void addPlatform(double x, double y, double width, double height, Color color) {
        // Добавляем платформу в список
        Platform p = new Platform(x, y, width, height, color);
        platforms.add(p);

        // Создаем визуальный элемент
        Rectangle r = new Rectangle(width, height);
        r.setFill(color);
        r.setStroke(color.darker());
        r.setStrokeWidth(2);
        r.setTranslateX(x);
        r.setTranslateY(y);
        platformViews.add(r);
        gamePane.getChildren().add(0, r);
    }

    private void loadNextLevel() {
        levelCompleteMenu.setVisible(false);
        pauseOverlay.setVisible(false);

        if (currentLevel < 3) {
            currentLevel++;
            player.reset(START_X, START_Y);
            score = 0;
            loadLevel(currentLevel);
            paused = false;
            updateUI();
        } else {
            // Все уровни пройдены!
            showAllLevelsComplete();
        }
    }

    private void showAllLevelsComplete() {
        levelCompleteMenu.setVisible(false);
        pauseOverlay.setVisible(true);
        pauseOverlay.toFront();

        VBox allCompleteMenu = new VBox(30);
        allCompleteMenu.setStyle("-fx-background-color: rgba(255, 215, 0, 0.95); -fx-padding: 50; -fx-alignment: center; -fx-border-color: gold; -fx-border-width: 5;");
        allCompleteMenu.setPrefSize(450, 350);
        allCompleteMenu.setLayoutX(225);
        allCompleteMenu.setLayoutY(125);

        Label congratsLabel = new Label("🎉 ПОЗДРАВЛЯЕМ! 🎉");
        congratsLabel.setStyle("-fx-font-size: 42; -fx-text-fill: #FF6B00; -fx-font-weight: bold;");

        Label messageLabel = new Label("Вы прошли все уровни!");
        messageLabel.setStyle("-fx-font-size: 24; -fx-text-fill: #8B4513;");

        Label scoreLabel = new Label("Финальный счет: " + score);
        scoreLabel.setStyle("-fx-font-size: 20; -fx-text-fill: #8B4513;");

        Button menuBtn = new Button("🏠 В меню");
        menuBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 280; -fx-pref-height: 50; -fx-background-color: #3498DB; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        menuBtn.setOnAction(e -> {
            gamePane.getChildren().remove(allCompleteMenu);
            returnToMenu();
        });

        Button exitBtn = new Button("✕ Выход");
        exitBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 280; -fx-pref-height: 50; -fx-background-color: #E74C3C; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        exitBtn.setOnAction(e -> System.exit(0));

        allCompleteMenu.getChildren().addAll(congratsLabel, messageLabel, scoreLabel, menuBtn, exitBtn);
        gamePane.getChildren().add(allCompleteMenu);
        allCompleteMenu.toFront();
    }

    private void setupPlayer() {
        player = new Player(START_X, START_Y, 36, 48);
        playerView = new Rectangle(player.getWidth(), player.getHeight());
        playerView.setFill(Color.DODGERBLUE);
        playerView.setStroke(Color.BLUE);
        playerView.setStrokeWidth(2);
        updatePlayerView();
        gamePane.getChildren().add(playerView);
    }

    private void setupPlatforms() {
        platforms.add(new Platform(0, 520, 900, 80));       // Земля
        platforms.add(new Platform(100, 440, 120, 20));     // Платформа 1
        platforms.add(new Platform(300, 380, 120, 20));     // Платформа 2
        platforms.add(new Platform(500, 320, 120, 20));     // Платформа 3
        platforms.add(new Platform(650, 280, 100, 20));     // Платформа 4
        platforms.add(new Platform(750, 200, 120, 20));     // Платформа 5

        for (Platform p : platforms) {
            Rectangle r = new Rectangle(p.getWidth(), p.getHeight());
            r.setFill(Color.DARKGRAY);
            r.setStroke(Color.BLACK);
            r.setStrokeWidth(1);
            r.setTranslateX(p.getX());
            r.setTranslateY(p.getY());
            gamePane.getChildren().add(0, r);
        }
    }

    private void setupCoins() {
        // Монеты на платформах
        coins.add(new Coin(150, 410, 20));
        coins.add(new Coin(350, 350, 20));
        coins.add(new Coin(550, 290, 20));
        coins.add(new Coin(680, 250, 20));
        coins.add(new Coin(800, 170, 20));
        coins.add(new Coin(200, 490, 20));
        coins.add(new Coin(400, 490, 20));
        coins.add(new Coin(600, 490, 20));

        for (Coin coin : coins) {
            Circle circle = new Circle(coin.getSize() / 2);
            circle.setFill(Color.GOLD);
            circle.setStroke(Color.ORANGE);
            circle.setStrokeWidth(2);
            circle.setTranslateX(coin.getX() + coin.getSize() / 2);
            circle.setTranslateY(coin.getY() + coin.getSize() / 2);
            coinViews.add(circle);
            gamePane.getChildren().add(circle);
        }
    }

    private void setupEnemies() {
        // Враги патрулируют платформы
        enemies.add(new Enemy(110, 412, 30, 30, 100, 200, 60));
        enemies.add(new Enemy(310, 352, 30, 30, 300, 400, 50));
        enemies.add(new Enemy(510, 292, 30, 30, 500, 600, 70));

        for (Enemy enemy : enemies) {
            Rectangle rect = new Rectangle(enemy.getWidth(), enemy.getHeight());
            rect.setFill(Color.DARKRED);
            rect.setStroke(Color.RED);
            rect.setStrokeWidth(2);
            rect.setTranslateX(enemy.getX());
            rect.setTranslateY(enemy.getY());
            enemyViews.add(rect);
            gamePane.getChildren().add(rect);
        }
    }

    // =============== УРОВНИ ===============

    private void setupLevel1() {
        // УРОВЕНЬ 1 - ЛЕГКИЙ (мало врагов, простые прыжки)

        // Платформы
        platforms.add(new Platform(0, 520, 900, 80));       // Земля
        platforms.add(new Platform(150, 440, 150, 20));
        platforms.add(new Platform(400, 380, 150, 20));
        platforms.add(new Platform(650, 320, 150, 20));
        platforms.add(new Platform(300, 260, 150, 20));
        platforms.add(new Platform(100, 180, 150, 20));

        for (Platform p : platforms) {
            Rectangle r = new Rectangle(p.getWidth(), p.getHeight());
            r.setFill(Color.GREEN.darker());
            r.setStroke(Color.DARKGREEN);
            r.setStrokeWidth(2);
            r.setTranslateX(p.getX());
            r.setTranslateY(p.getY());
            gamePane.getChildren().add(0, r);
        }

        // Монеты (много)
        addCoin(200, 410);
        addCoin(450, 350);
        addCoin(700, 290);
        addCoin(350, 230);
        addCoin(150, 150);
        addCoin(300, 490);
        addCoin(500, 490);
        addCoin(700, 490);

        // Враги (мало, медленные)
        addEnemy(160, 412, 150, 280, 50);
        addEnemy(410, 352, 400, 530, 45);
    }


    private void setupLevel3() {
        // УРОВЕНЬ 3 - СЛОЖНЫЙ (много врагов, сложные прыжки)

        // Платформы
        platforms.add(new Platform(0, 520, 900, 80));       // Земля
        platforms.add(new Platform(50, 450, 80, 20));
        platforms.add(new Platform(200, 400, 80, 20));
        platforms.add(new Platform(350, 350, 80, 20));
        platforms.add(new Platform(500, 300, 80, 20));
        platforms.add(new Platform(650, 250, 80, 20));
        platforms.add(new Platform(770, 200, 80, 20));
        platforms.add(new Platform(650, 150, 80, 20));
        platforms.add(new Platform(500, 100, 80, 20));
        platforms.add(new Platform(350, 50, 80, 20));

        for (Platform p : platforms) {
            Rectangle r = new Rectangle(p.getWidth(), p.getHeight());
            r.setFill(Color.RED.darker());
            r.setStroke(Color.DARKRED);
            r.setStrokeWidth(2);
            r.setTranslateX(p.getX());
            r.setTranslateY(p.getY());
            gamePane.getChildren().add(0, r);
        }

        // Монеты
        addCoin(70, 420);
        addCoin(220, 370);
        addCoin(370, 320);
        addCoin(520, 270);
        addCoin(670, 220);
        addCoin(790, 170);
        addCoin(670, 120);
        addCoin(520, 70);
        addCoin(370, 20);
        addCoin(250, 490);
        addCoin(450, 490);
        addCoin(650, 490);

        // Враги (много, быстрые) - ИСПРАВЛЕНО: первый враг не на месте спавна!
        addEnemy(210, 372, 200, 260, 85);      // Переместили первого врага на вторую платформу
        addEnemy(360, 322, 350, 410, 90);
        addEnemy(510, 272, 500, 560, 95);
        addEnemy(660, 222, 650, 710, 100);
        addEnemy(780, 172, 770, 830, 85);
        addEnemy(300, 492, 250, 400, 70);      // Враг на земле
    }

    private void addCoin(double x, double y) {
        Coin coin = new Coin(x, y, 20);
        coins.add(coin);

        Circle circle = new Circle(coin.getSize() / 2);
        circle.setFill(Color.GOLD);
        circle.setStroke(Color.ORANGE);
        circle.setStrokeWidth(2);
        circle.setTranslateX(coin.getX() + coin.getSize() / 2);
        circle.setTranslateY(coin.getY() + coin.getSize() / 2);
        coinViews.add(circle);
        gamePane.getChildren().add(circle);
    }

    private void addEnemy(double x, double y, double minX, double maxX, double speed) {
        Enemy enemy = new Enemy(x, y, 30, 30, minX, maxX, speed);
        enemies.add(enemy);

        Rectangle rect = new Rectangle(enemy.getWidth(), enemy.getHeight());
        rect.setFill(Color.DARKRED);
        rect.setStroke(Color.RED);
        rect.setStrokeWidth(2);
        rect.setTranslateX(enemy.getX());
        rect.setTranslateY(enemy.getY());
        enemyViews.add(rect);
        gamePane.getChildren().add(rect);
    }

    private void setupInput() {
        gamePane.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                newScene.setOnKeyPressed(e -> {
                    keys.put(e.getCode(), true);
                    if (e.getCode() == KeyCode.ESCAPE) {
                        togglePause();
                    }
                });
                newScene.setOnKeyReleased(e -> keys.put(e.getCode(), false));
            }
        });
    }

    private void setupPauseOverlay() {
        // Создаем затемнение на весь экран
        pauseOverlay = new Rectangle(900, 600);
        pauseOverlay.setFill(Color.rgb(0, 0, 0, 0.7)); // Черный с прозрачностью 70%
        pauseOverlay.setVisible(false);
        gamePane.getChildren().add(pauseOverlay);
    }

    private void setupPauseMenu() {
        pauseMenu = new VBox(20);
        pauseMenu.setStyle("-fx-background-color: rgba(0, 0, 0, 0.95); -fx-padding: 40; -fx-alignment: center; -fx-border-color: white; -fx-border-width: 3;");
        pauseMenu.setPrefSize(300, 250);
        pauseMenu.setLayoutX(300);
        pauseMenu.setLayoutY(175);
        pauseMenu.setVisible(false);

        Label pauseLabel = new Label("ПАУЗА");
        pauseLabel.setStyle("-fx-font-size: 32; -fx-text-fill: white; -fx-font-weight: bold;");

        Button resumeBtn = new Button("Продолжить");
        resumeBtn.setStyle("-fx-font-size: 16; -fx-pref-width: 200;");
        resumeBtn.setOnAction(e -> togglePause());

        Button menuBtn = new Button("В меню");
        menuBtn.setStyle("-fx-font-size: 16; -fx-pref-width: 200;");
        menuBtn.setOnAction(e -> returnToMenu());

        Button exitBtn = new Button("Выход");
        exitBtn.setStyle("-fx-font-size: 16; -fx-pref-width: 200;");
        exitBtn.setOnAction(e -> System.exit(0));

        pauseMenu.getChildren().addAll(pauseLabel, resumeBtn, menuBtn, exitBtn);
        gamePane.getChildren().add(pauseMenu);
    }

    private void setupGameOverMenu() {
        gameOverMenu = new VBox(25);
        gameOverMenu.setStyle("-fx-background-color: rgba(139, 0, 0, 0.9); -fx-padding: 50; -fx-alignment: center; -fx-border-color: red; -fx-border-width: 3;");
        gameOverMenu.setPrefSize(400, 350);
        gameOverMenu.setLayoutX(250);
        gameOverMenu.setLayoutY(125);
        gameOverMenu.setVisible(false);

        Label gameOverLabel = new Label("GAME OVER");
        gameOverLabel.setStyle("-fx-font-size: 48; -fx-text-fill: #FF6B6B; -fx-font-weight: bold;");

        Label finalScoreLabel = new Label("Финальный счет: 0");
        finalScoreLabel.setStyle("-fx-font-size: 24; -fx-text-fill: white;");
        finalScoreLabel.setId("finalScoreLabel");

        Button restartBtn = new Button("🔄 Играть снова");
        restartBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 250; -fx-pref-height: 50; -fx-background-color: #27AE60; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        restartBtn.setOnAction(e -> restartGame());

        Button menuBtn = new Button("🏠 В меню");
        menuBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 250; -fx-pref-height: 50; -fx-background-color: #3498DB; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        menuBtn.setOnAction(e -> returnToMenu());

        Button exitBtn = new Button("✕ Выход");
        exitBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 250; -fx-pref-height: 50; -fx-background-color: #E74C3C; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        exitBtn.setOnAction(e -> System.exit(0));

        gameOverMenu.getChildren().addAll(gameOverLabel, finalScoreLabel, restartBtn, menuBtn, exitBtn);
        gamePane.getChildren().add(gameOverMenu);
    }

    private void setupLevelCompleteMenu() {
        levelCompleteMenu = new VBox(25);
        levelCompleteMenu.setStyle("-fx-background-color: rgba(0, 139, 0, 0.9); -fx-padding: 50; -fx-alignment: center; -fx-border-color: lime; -fx-border-width: 3;");
        levelCompleteMenu.setPrefSize(400, 400);
        levelCompleteMenu.setLayoutX(250);
        levelCompleteMenu.setLayoutY(100);
        levelCompleteMenu.setVisible(false);

        Label completeLabel = new Label("УРОВЕНЬ ПРОЙДЕН!");
        completeLabel.setStyle("-fx-font-size: 40; -fx-text-fill: #90EE90; -fx-font-weight: bold;");

        Label scoreLabel = new Label("Счет: 0");
        scoreLabel.setStyle("-fx-font-size: 24; -fx-text-fill: white;");
        scoreLabel.setId("levelCompleteScore");

        Label coinsLabel = new Label("Монет собрано: 0/0");
        coinsLabel.setStyle("-fx-font-size: 20; -fx-text-fill: white;");
        coinsLabel.setId("levelCompleteCoins");

        Button nextBtn = new Button("➡️ Следующий уровень");
        nextBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 280; -fx-pref-height: 50; -fx-background-color: #27AE60; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        nextBtn.setOnAction(e -> loadNextLevel());
        nextBtn.setId("nextLevelBtn");

        Button retryBtn = new Button("🔄 Повторить уровень");
        retryBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 280; -fx-pref-height: 50; -fx-background-color: #F39C12; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        retryBtn.setOnAction(e -> restartGame());

        Button menuBtn = new Button("🏠 В меню");
        menuBtn.setStyle("-fx-font-size: 18; -fx-pref-width: 280; -fx-pref-height: 50; -fx-background-color: #3498DB; -fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
        menuBtn.setOnAction(e -> returnToMenu());

        levelCompleteMenu.getChildren().addAll(completeLabel, scoreLabel, coinsLabel, nextBtn, retryBtn, menuBtn);
        gamePane.getChildren().add(levelCompleteMenu);
    }

    @FXML
    private void onPause() {
        togglePause();
    }

    private void togglePause() {
        paused = !paused;
        pauseOverlay.setVisible(paused);
        pauseMenu.setVisible(paused);

        if (paused) {
            pauseButton.setText("Продолжить");
            pauseOverlay.toFront();
            pauseMenu.toFront();
        } else {
            pauseButton.setText("Пауза");
        }
    }

    private void returnToMenu() {
        try {
            gameLoop.stop();
            Stage stage = (Stage) gamePane.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
            Parent root = loader.load();
            MenuController controller = loader.getController();
            controller.setStage(stage);
            stage.setScene(new Scene(root, 900, 600));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onReset() {
        restartGame();
    }

    private void restartGame() {
        // Скрываем все меню и затемнение
        gameOverMenu.setVisible(false);
        levelCompleteMenu.setVisible(false);
        pauseOverlay.setVisible(false);

        // Сбрасываем игрока
        player.reset(START_X, START_Y);
        score = 0;
        cameraX = 0; // Сброс камеры!

        // Перезагружаем текущий уровень
        loadLevel(currentLevel);

        // Возобновляем игру
        paused = false;
        pauseButton.setText("Пауза");

        updatePlayerView();
        updateUI();
    }

    private void startLoop() {
        gameLoop = new AnimationTimer() {
            private long last = 0;

            @Override
            public void handle(long now) {
                if (last == 0) last = now;
                double delta = (now - last) / 1_000_000_000.0;

                if (!paused && !player.isDead()) {
                    update(delta);
                    render();
                }

                last = now;
            }
        };
        gameLoop.start();
    }

    private void update(double dt) {
        player.savePrevPosition();

        // Управление только WASD
        if (isPressed(KeyCode.A)) {
            player.moveX(-220 * dt);
        }
        if (isPressed(KeyCode.D)) {
            player.moveX(220 * dt);
        }

        // ИСПРАВЛЕННЫЙ ДВОЙНОЙ ПРЫЖОК - проверяем момент нажатия!
        boolean wKeyPressed = isPressed(KeyCode.W);
        if (wKeyPressed && !wKeyWasPressed) {
            // Клавиша только что нажата!
            player.jump();
        }
        wKeyWasPressed = wKeyPressed;

        // Физика
        player.applyGravity(dt);

        // Проверка коллизий
        checkCollisions();

        // Границы уровня
        if (currentLevel == 1) {
            // Для scrolling уровня - широкие границы
            if (player.getX() < 0) player.setX(0);
            if (player.getX() + player.getWidth() > LEVEL_WIDTH) {
                player.setX(LEVEL_WIDTH - player.getWidth());
            }
        } else {
            // Для обычных уровней - границы экрана
            if (player.getX() < 0) player.setX(0);
            if (player.getX() + player.getWidth() > SCREEN_WIDTH) {
                player.setX(SCREEN_WIDTH - player.getWidth());
            }
        }

        // Обновление камеры - только для уровня 1
        if (currentLevel == 1) {
            updateCamera();
        }

        // Проверка падения в бездну
        if (player.getY() > 600) {
            player.loseLife();
            if (!player.isDead()) {
                respawnPlayer();
            } else {
                gameOver();
            }
        }

        // Обновление врагов
        for (int i = 0; i < enemies.size(); i++) {
            enemies.get(i).update(dt);
        }

        // Проверка столкновения с врагами (с возможностью убийства)
        for (int i = enemies.size() - 1; i >= 0; i--) {
            Enemy enemy = enemies.get(i);
            if (enemy.intersects(player)) {
                // Проверяем, прыгает ли игрок на врага сверху
                double playerBottom = player.getY() + player.getHeight();
                double enemyTop = enemy.getY();
                double playerPrevBottom = player.getPrevY() + player.getHeight();

                // Если игрок был выше врага и падает вниз (velocityY > 0)
                if (playerPrevBottom <= enemyTop + 5 && player.getVelocityY() > 0) {
                    // УБИВАЕМ ВРАГА!
                    enemies.remove(i);
                    Rectangle enemyView = enemyViews.remove(i);
                    gamePane.getChildren().remove(enemyView);

                    // Даем небольшой отскок игроку
                    player.setVelocityY(-300);

                    // Даем бонусные очки
                    score += 50;
                } else {
                    // Обычное столкновение - игрок получает урон
                    player.loseLife();
                    if (!player.isDead()) {
                        respawnPlayer();
                    } else {
                        gameOver();
                    }
                }
                break;
            }
        }

        // Сбор монет
        int collectedCoins = 0;
        for (int i = 0; i < coins.size(); i++) {
            Coin coin = coins.get(i);
            if (coin.isCollected()) {
                collectedCoins++;
            } else if (coin.intersects(player)) {
                coin.collect();
                coinViews.get(i).setVisible(false);
                score += 10;
                collectedCoins++;
            }
        }

        // Проверка достижения финиша (только для уровня 1)
        if (currentLevel == 1 && finishLine != null) {
            // Проверяем реальные координаты игрока и финиша
            double finishX = 3500;
            double finishY = 370;
            double finishW = 50;
            double finishH = 150;

            if (player.getX() + player.getWidth() > finishX &&
                    player.getX() < finishX + finishW &&
                    player.getY() + player.getHeight() > finishY &&
                    player.getY() < finishY + finishH) {
                levelComplete();
            }
        }

        // Для уровней 2 и 3 - сбор всех монет
        if (currentLevel != 1) {
            if (collectedCoins == totalCoins && totalCoins > 0) {
                levelComplete();
            }
        }

        updateUI();
    }

    private void updateCamera() {
        // Камера следует за игроком, держа его в центре экрана
        double targetCameraX = player.getX() - SCREEN_WIDTH / 2;

        // Ограничиваем камеру границами уровня
        if (targetCameraX < 0) targetCameraX = 0;
        if (targetCameraX > LEVEL_WIDTH - SCREEN_WIDTH) {
            targetCameraX = LEVEL_WIDTH - SCREEN_WIDTH;
        }

        cameraX = targetCameraX;
    }

    private void levelComplete() {
        paused = true;

        // Показываем затемнение
        pauseOverlay.setVisible(true);
        pauseOverlay.toFront();

        // Обновляем информацию в меню завершения уровня
        for (javafx.scene.Node node : levelCompleteMenu.getChildren()) {
            if (node instanceof Label) {
                Label label = (Label) node;
                if ("levelCompleteScore".equals(label.getId())) {
                    label.setText("Счет: " + score);
                } else if ("levelCompleteCoins".equals(label.getId())) {
                    if (currentLevel == 1) {
                        label.setText("Вы добрались до финиша!");
                    } else {
                        int collected = 0;
                        for (Coin c : coins) {
                            if (c.isCollected()) collected++;
                        }
                        label.setText("Монет собрано: " + collected + "/" + totalCoins);
                    }
                }
            } else if (node instanceof Button && "nextLevelBtn".equals(node.getId())) {
                // Показываем кнопку "Следующий уровень" если не последний уровень
                node.setVisible(currentLevel < 3);
            }
        }

        // Показываем меню завершения уровня
        levelCompleteMenu.setVisible(true);
        levelCompleteMenu.toFront();
    }

    private void checkCollisions() {
        player.setOnGround(false);

        for (Platform p : platforms) {
            if (player.intersects(p)) {
                resolveCollision(p);
            }
        }
    }

    private void resolveCollision(Platform p) {
        double playerBottom = player.getY() + player.getHeight();
        double playerPrevBottom = player.getPrevY() + player.getHeight();
        double platformTop = p.getY();
        double platformBottom = p.getY() + p.getHeight();

        boolean fromAbove = playerPrevBottom <= platformTop + 5;
        boolean fromBelow = player.getPrevY() >= platformBottom - 5;
        boolean fromLeft = player.getPrevX() + player.getWidth() <= p.getX() + 5;
        boolean fromRight = player.getPrevX() >= p.getX() + p.getWidth() - 5;

        double overlapX = Math.min(
                player.getX() + player.getWidth() - p.getX(),
                p.getX() + p.getWidth() - player.getX()
        );
        double overlapY = Math.min(
                player.getY() + player.getHeight() - p.getY(),
                p.getY() + p.getHeight() - player.getY()
        );

        if (overlapX < overlapY) {
            if (fromLeft) {
                player.setX(p.getX() - player.getWidth());
            } else if (fromRight) {
                player.setX(p.getX() + p.getWidth());
            }
        } else {
            if (fromAbove && player.getVelocityY() >= 0) {
                player.landOn(platformTop - player.getHeight());
                player.setOnGround(true);
            } else if (fromBelow && player.getVelocityY() <= 0) {
                player.setY(platformBottom);
                player.setVelocityY(0);
            }
        }
    }

    private void respawnPlayer() {
        player.setX(START_X);
        player.setY(START_Y);
        player.resetVelocity();
        player.setOnGround(false);
    }

    private void gameOver() {
        paused = true;

        // Показываем затемнение
        pauseOverlay.setVisible(true);
        pauseOverlay.toFront();

        // Обновляем финальный счет в меню Game Over
        for (javafx.scene.Node node : gameOverMenu.getChildren()) {
            if (node instanceof Label && node.getId() != null && node.getId().equals("finalScoreLabel")) {
                ((Label) node).setText("Финальный счет: " + score);
                break;
            }
        }

        // Показываем меню Game Over
        gameOverMenu.setVisible(true);
        gameOverMenu.toFront();
    }

    private void render() {
        // Обновляем игрока
        updatePlayerView();

        // Обновляем платформы с учетом камеры (только для уровня 1)
        if (currentLevel == 1) {
            for (int i = 0; i < platformViews.size(); i++) {
                Rectangle view = platformViews.get(i);
                Platform p = platforms.get(i);
                view.setTranslateX(p.getX() - cameraX);
                view.setTranslateY(p.getY());
            }

            // Обновляем финишную линию
            if (finishLine != null) {
                finishLine.setTranslateX(3500 - cameraX);
            }
        }

        // Обновляем монеты с учетом камеры
        for (int i = 0; i < coins.size(); i++) {
            Coin coin = coins.get(i);
            Circle view = coinViews.get(i);
            if (currentLevel == 1) {
                view.setTranslateX(coin.getX() + coin.getSize() / 2 - cameraX);
            } else {
                view.setTranslateX(coin.getX() + coin.getSize() / 2);
            }
            view.setTranslateY(coin.getY() + coin.getSize() / 2);
        }

        // Обновляем врагов с учетом камеры
        for (int i = 0; i < enemies.size(); i++) {
            Enemy enemy = enemies.get(i);
            Rectangle view = enemyViews.get(i);
            if (currentLevel == 1) {
                view.setTranslateX(enemy.getX() - cameraX);
            } else {
                view.setTranslateX(enemy.getX());
            }
            view.setTranslateY(enemy.getY());
        }
    }

    private void updatePlayerView() {
        if (currentLevel == 1) {
            // Для scrolling уровня - игрок относительно камеры
            playerView.setTranslateX(player.getX() - cameraX);
        } else {
            // Для обычных уровней - абсолютная позиция
            playerView.setTranslateX(player.getX());
        }
        playerView.setTranslateY(player.getY());
    }

    private void updateUI() {
        scoreLabel.setText("Score: " + score);
        livesLabel.setText("Lives: " + player.getLives());
    }

    private boolean isPressed(KeyCode key) {
        return keys.getOrDefault(key, false);
    }
}