package org.example.platformergame;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class LevelSelectController {

    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private void onLevel1() {
        loadLevel(1);
    }

    @FXML
    private void onLevel2() {
        loadLevel(2);
    }

    @FXML
    private void onLevel3() {
        loadLevel(3);
    }

    @FXML
    private void onBack() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("Menu.fxml")
            );
            Parent root = loader.load();
            MenuController controller = loader.getController();
            controller.setStage(stage);
            stage.setScene(new Scene(root, 900, 600));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadLevel(int levelNumber) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("Game.fxml")
            );
            Parent root = loader.load();

            // Передаем номер уровня в контроллер игры
            GameController controller = loader.getController();
            controller.setLevel(levelNumber);

            Scene gameScene = new Scene(root, 900, 600);
            stage.setScene(gameScene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}