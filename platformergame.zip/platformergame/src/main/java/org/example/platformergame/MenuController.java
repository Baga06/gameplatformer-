package org.example.platformergame;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MenuController {

    private Stage stage;

    // Получаем stage из GameApplication
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private void onPlay() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("Game.fxml")
            );
            Parent root = loader.load();

            Scene gameScene = new Scene(root, 900, 600);
            stage.setScene(gameScene); // ← ВОТ ЗДЕСЬ открывается игра

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onExit() {
        System.exit(0);
    }
}
