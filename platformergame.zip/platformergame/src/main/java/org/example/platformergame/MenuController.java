package org.example.platformergame;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

public class MenuController {

    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private void onPlay() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("Game.fxml")
            );
            Parent root = loader.load();
            Scene gameScene = new Scene(root, 900, 600);
            stage.setScene(gameScene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onInstructions() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Инструкция");
        alert.setHeaderText("Как играть в Platformer Game");
        alert.setContentText(
                "🎯 ЦЕЛЬ ИГРЫ:\n" +
                        "Собирайте золотые монеты и избегайте красных врагов!\n\n" +

                        "🎮 УПРАВЛЕНИЕ:\n" +
                        "• A / ← - Движение влево\n" +
                        "• D / → - Движение вправо\n" +
                        "• SPACE / W / ↑ - Прыжок\n" +
                        "• ESC - Пауза\n\n" +

                        "⚠️ ПРАВИЛА:\n" +
                        "• У вас 3 жизни\n" +
                        "• Касание врага = -1 жизнь\n" +
                        "• Падение в бездну = -1 жизнь\n" +
                        "• Каждая монета = +10 очков\n\n" +

                        "💡 СОВЕТ:\n" +
                        "Прыгайте точно и избегайте патрулирующих врагов!"
        );
        alert.showAndWait();
    }

    @FXML
    private void onExit() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Выход");
        alert.setHeaderText("Вы уверены, что хотите выйти?");
        alert.setContentText("Игра будет закрыта.");

        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                System.exit(0);
            }
        });
    }
}