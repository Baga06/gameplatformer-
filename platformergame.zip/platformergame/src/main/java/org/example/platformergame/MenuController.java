package org.example.platformergame;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;
public class MenuController {

    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    // ========== КНОПКА "ИГРАТЬ" ==========
    @FXML
    private void onStart() {  // Изменил с onPlay() на onStart()
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("LevelSelect.fxml")
            );
            Parent root = loader.load();
            LevelSelectController controller = loader.getController();
            controller.setStage(stage);
            stage.setScene(new Scene(root, 900, 600));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ========== НОВАЯ КНОПКА "СТАТИСТИКА" ==========
    @FXML
    private void onStatistics() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("Statistics.fxml")
            );
            Parent root = loader.load();
            StatisticsController controller = loader.getController();
            controller.setStage(stage);
            stage.setScene(new Scene(root, 900, 600));
        } catch (Exception e) {
            System.err.println("❌ Ошибка при открытии статистики: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ========== КНОПКА "ИНСТРУКЦИЯ" ==========
    @FXML
    private void onInstructions() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("How to play");
        alert.setHeaderText("How to play Last Jump");
        alert.setContentText(
                "🎮 CONTROLS:\n" +
                        "• A - Move left\n" +
                        "• D - Move right\n" +
                        "• W - Jump (can jump twice in the air!)\n" +
                        "• ESC/Space - Pause\n\n" +

                        "✨ DOUBLE JUMP:\n" +
                        "• W in the air = second jump!\n" +
                        "• Needed for long jumps\n\n" +

                        "⚠️ RULES:\n" +
                        "• 3 lives at the start\n" +
                        "• Falling into the abyss = respawn at the beginning\n" +
                        "• Coins = +10 points\n\n"
        );
        alert.showAndWait();
    }

    // ========== КНОПКА "ВЫХОД" ==========
    @FXML
    private void onExit() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit");
        alert.setHeaderText("Are you sure you want to exit?");
        alert.setContentText("The game will be closed.");

        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                System.exit(0);
            }
        });
    }
}