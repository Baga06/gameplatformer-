package org.example.platformergame;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

public class MenuController {

    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private void onPlay() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("LevelSelect.fxml")
            );
            Parent root = loader.load();
            LevelSelectController controller = loader.getController();
            controller.setStage(stage);
            stage.setScene(new Scene(root, 900, 600));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onInstructions() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Инструкция");
        alert.setHeaderText("Как играть в Platformer Game");
        alert.setContentText(
                "🎯 ЦЕЛЬ ИГРЫ:\n" +
                        "• Уровень 1: Добегите до ФИНИША!\n" +
                        "• Уровни 2-3: Соберите ВСЕ монеты!\n\n" +

                        "🎮 УПРАВЛЕНИЕ:\n" +
                        "• A - Движение влево\n" +
                        "• D - Движение вправо\n" +
                        "• W - Прыжок (можно дважды в воздухе!)\n" +
                        "• ESC - Пауза\n\n" +

                        "⚔️ БОЕВАЯ СИСТЕМА:\n" +
                        "• Прыгайте НА врага сверху чтобы убить!\n" +
                        "• Убийство = +50 очков\n" +
                        "• Касание сбоку = -1 жизнь + отталкивание\n\n" +

                        "🤖 AI ВРАГОВ:\n" +
                        "• Враги ВИДЯТ вас в радиусе 300 пикселей!\n" +
                        "• Начинают ПРЕСЛЕДОВАТЬ когда заметят\n" +
                        "• Становятся краснее при преследовании\n" +
                        "• Бегут в 1.5 раза быстрее!\n\n" +

                        "💥 СИСТЕМА УРОНА:\n" +
                        "• При ударе вас ОТТАЛКИВАЕТ назад\n" +
                        "• 2 секунды неуязвимости (мигаете)\n" +
                        "• Используйте для побега!\n\n" +

                        "✨ ДВОЙНОЙ ПРЫЖОК:\n" +
                        "• W в воздухе = второй прыжок!\n" +
                        "• Необходим для дальних прыжков\n\n" +

                        "⚠️ ПРАВИЛА:\n" +
                        "• 3 жизни в начале\n" +
                        "• Падение в бездну = респавн в начале\n" +
                        "• Монеты = +10 очков\n\n" +

                        "💡 СОВЕТ:\n" +
                        "Следите за цветом врагов - красный = опасность!"
        );
        alert.showAndWait();
    }

    @FXML
    private void onExit() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Выход");
        alert.setHeaderText("Вы уверены, что хотите выйти?");
        alert.setContentText("Игра будет закрыта.");

        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                System.exit(0);
            }
        });
    }
}