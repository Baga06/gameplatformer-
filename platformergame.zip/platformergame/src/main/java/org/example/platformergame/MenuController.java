package org.example.platformergame;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

public class MenuController {

    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private void onPlay() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("LevelSelect.fxml")
            );
            Parent root = loader.load();
            LevelSelectController controller = loader.getController();
            controller.setStage(stage);
            stage.setScene(new Scene(root, 900, 600));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onInstructions() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Инструкция");
        alert.setHeaderText("Как играть в Platformer Game");
        alert.setContentText(
                "🎯 ЦЕЛЬ ИГРЫ:\n" +
                        "Добегите до ФИНИШНОЙ ЛИНИИ в конце уровня!\n\n" +

                        "📹 ПРОКРУТКА:\n" +
                        "• Уровень длиннее экрана!\n" +
                        "• Камера следует за вами\n" +
                        "• Новые зоны появляются по мере продвижения\n\n" +

                        "🎮 УПРАВЛЕНИЕ:\n" +
                        "• A - Движение влево\n" +
                        "• D - Движение вправо\n" +
                        "• W - Прыжок (можно дважды в воздухе!)\n" +
                        "• ESC - Пауза\n\n" +

                        "⚔️ БОЕВАЯ СИСТЕМА:\n" +
                        "• Прыгайте НА врага сверху чтобы убить его!\n" +
                        "• Убийство врага = +50 очков\n" +
                        "• Касание врага сбоку = -1 жизнь\n\n" +

                        "✨ ДВОЙНОЙ ПРЫЖОК:\n" +
                        "• Нажмите W в воздухе для второго прыжка!\n" +
                        "• Необходим для высоких платформ!\n\n" +

                        "⚠️ ПРАВИЛА:\n" +
                        "• У вас 3 жизни\n" +
                        "• Падение = -1 жизнь\n" +
                        "• Монеты дают очки но необязательны\n" +
                        "• Достигните 🏁 ФИНИША чтобы выиграть!\n\n" +

                        "🗺️ УРОВЕНЬ:\n" +
                        "• Длина: 3600 пикселей (4 экрана)\n" +
                        "• 6 разных цветных секций\n" +
                        "• 27 монет, 16 врагов\n\n" +

                        "💡 СОВЕТ:\n" +
                        "Используйте двойной прыжок для дальних расстояний!"
        );
        alert.showAndWait();
    }

    @FXML
    private void onExit() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Выход");
        alert.setHeaderText("Вы уверены, что хотите выйти?");
        alert.setContentText("Игра будет закрыта.");

        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                System.exit(0);
            }
        });
    }
}