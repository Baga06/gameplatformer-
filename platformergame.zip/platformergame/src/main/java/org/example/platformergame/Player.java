package org.example.platformergame;

public class Player {

    private double x, y;
    private double prevY;

    private final double width;
    private final double height;

    private double velocityY = 0;

    private boolean onGround = false;

    private static final double GRAVITY = 1200;
    private static final double JUMP_FORCE = -450;

    public Player(double x, double y, double width, double height) {
        this.x = x;
        this.y = y;
        this.prevY = y;
        this.width = width;
        this.height = height;
    }

    // === ПОЛОЖЕНИЕ ===
    public void savePrevY() {
        prevY = y;
    }

    public double getPrevY() {
        return prevY;
    }

    public double getX() { return x; }
    public double getY() { return y; }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getWidth() { return width; }
    public double getHeight() { return height; }

    // === ДВИЖЕНИЕ ===
    public void moveX(double dx) {
        x += dx;
    }

    public void jump() {
        velocityY = JUMP_FORCE;
        onGround = false;
    }

    public void applyGravity(double dt) {
        velocityY += GRAVITY * dt;
        y += velocityY * dt;
    }

    public void landOn(double yPos) {
        y = yPos;
        velocityY = 0;
        onGround = true;
    }

    public void resetVelocity() {
        velocityY = 0;
    }

    // === СОСТОЯНИЯ ===
    public boolean isOnGround() {
        return onGround;
    }

    public void setOnGround(boolean value) {
        onGround = value;
    }

    // === КОЛЛИЗИИ ===
    public boolean intersects(Platform p) {
        return x < p.getX() + p.getWidth()
                && x + width > p.getX()
                && y < p.getY() + p.getHeight()
                && y + height > p.getY();
    }
}
