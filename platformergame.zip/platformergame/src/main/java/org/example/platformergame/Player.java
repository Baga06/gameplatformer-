package org.example.platformergame;

public class Player {
    private double x, y;
    private double prevX, prevY;
    private final double width, height;
    private double velocityY = 0;
    private boolean onGround = false;
    private int lives = 3;
    private boolean isDead = false;
    private int jumpsRemaining = 2;

    private boolean onLadder = false;
    private static final double CLIMB_SPEED = 150;

    private static final double GRAVITY = 1200;
    private static final double JUMP_FORCE = -400; // ИЗМЕНЕНО: было -520, стало -400
    private static final int MAX_JUMPS = 2;

    public Player(double x, double y, double width, double height) {
        this.x = x;
        this.y = y;
        this.prevX = x;
        this.prevY = y;
        this.width = width;
        this.height = height;
    }

    public void savePrevPosition() {
        prevX = x;
        prevY = y;
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public double getPrevX() { return prevX; }
    public double getPrevY() { return prevY; }
    public double getWidth() { return width; }
    public double getHeight() { return height; }
    public double getVelocityY() { return velocityY; }
    public int getLives() { return lives; }
    public boolean isDead() { return isDead; }
    public boolean isOnLadder() { return onLadder; }

    public void setX(double x) { this.x = x; }
    public void setY(double y) { this.y = y; }
    public void setVelocityY(double vy) { this.velocityY = vy; }
    public void setLives(int lives) { this.lives = lives; }
    public void setOnLadder(boolean onLadder) {
        this.onLadder = onLadder;
        if (onLadder) {
            velocityY = 0;
        }
    }

    public void moveX(double dx) {
        x += dx;
    }

    public void climbUp(double dt) {
        if (onLadder) {
            y -= CLIMB_SPEED * dt;
            velocityY = 0;
        }
    }

    public void climbDown(double dt) {
        if (onLadder) {
            y += CLIMB_SPEED * dt;
            velocityY = 0;
        }
    }

    public void jump() {
        if (onLadder) {
            onLadder = false;
            velocityY = JUMP_FORCE;
            jumpsRemaining = 1;
        } else if (jumpsRemaining > 0) {
            velocityY = JUMP_FORCE;
            jumpsRemaining--;
            onGround = false;
        }
    }

    public void applyGravity(double dt) {
        if (!onLadder) {
            velocityY += GRAVITY * dt;
            y += velocityY * dt;
        }
    }

    public void landOn(double yPos) {
        y = yPos;
        velocityY = 0;
        onGround = true;
        onLadder = false;
        jumpsRemaining = MAX_JUMPS;
    }

    public boolean isOnGround() { return onGround; }

    public void setOnGround(boolean onGround) {
        this.onGround = onGround;
        if (onGround) {
            jumpsRemaining = MAX_JUMPS;
        }
    }

    public void resetVelocity() {
        velocityY = 0;
    }

    public void loseLife() {
        lives--;
        if (lives <= 0) {
            isDead = true;
        }
    }

    public void reset(double startX, double startY) {
        x = startX;
        y = startY;
        prevX = startX;
        prevY = startY;
        velocityY = 0;
        onGround = false;
        onLadder = false;
        lives = 3;
        isDead = false;
        jumpsRemaining = MAX_JUMPS;
    }

    public boolean intersects(Platform p) {
        return x < p.getX() + p.getWidth() &&
                x + width > p.getX() &&
                y < p.getY() + p.getHeight() &&
                y + height > p.getY();
    }

    public boolean intersects(double ex, double ey, double ew, double eh) {
        return x < ex + ew &&
                x + width > ex &&
                y < ey + eh &&
                y + height > ey;
    }
}