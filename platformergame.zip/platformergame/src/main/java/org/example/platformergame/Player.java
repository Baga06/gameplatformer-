package org.example.platformergame;

public class Player {
    private double x, y;
    private double prevX, prevY;
    private final double width, height;
    private double velocityY = 0;
    private boolean onGround = false;
    private int lives = 3;
    private boolean isDead = false;
    private int jumpsRemaining = 2; // Для двойного прыжка

    private static final double GRAVITY = 1200;
    private static final double JUMP_FORCE = -520;
    private static final int MAX_JUMPS = 2; // Максимум прыжков

    public Player(double x, double y, double width, double height) {
        this.x = x;
        this.y = y;
        this.prevX = x;
        this.prevY = y;
        this.width = width;
        this.height = height;
    }

    public void savePrevPosition() {
        prevX = x;
        prevY = y;
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public double getPrevX() { return prevX; }
    public double getPrevY() { return prevY; }
    public double getWidth() { return width; }
    public double getHeight() { return height; }
    public double getVelocityY() { return velocityY; }
    public int getLives() { return lives; }
    public boolean isDead() { return isDead; }

    public void setX(double x) { this.x = x; }
    public void setY(double y) { this.y = y; }
    public void setVelocityY(double vy) { this.velocityY = vy; }
    public void setLives(int lives) { this.lives = lives; }

    public void moveX(double dx) {
        x += dx;
    }

    public void jump() {
        // Можем прыгать если есть доступные прыжки
        if (jumpsRemaining > 0) {
            velocityY = JUMP_FORCE;
            jumpsRemaining--;
            onGround = false;
        }
    }

    public void applyGravity(double dt) {
        velocityY += GRAVITY * dt;
        y += velocityY * dt;
    }

    public void landOn(double yPos) {
        y = yPos;
        velocityY = 0;
        onGround = true;
        jumpsRemaining = MAX_JUMPS; // Восстанавливаем прыжки при приземлении
    }

    public boolean isOnGround() { return onGround; }

    public void setOnGround(boolean onGround) {
        this.onGround = onGround;
        if (onGround) {
            jumpsRemaining = MAX_JUMPS; // Восстанавливаем прыжки
        }
    }

    public void resetVelocity() {
        velocityY = 0;
    }

    public void loseLife() {
        lives--;
        if (lives <= 0) {
            isDead = true;
        }
    }

    public void reset(double startX, double startY) {
        x = startX;
        y = startY;
        prevX = startX;
        prevY = startY;
        velocityY = 0;
        onGround = false;
        lives = 3;
        isDead = false;
        jumpsRemaining = MAX_JUMPS;
    }

    public boolean intersects(Platform p) {
        return x < p.getX() + p.getWidth() &&
                x + width > p.getX() &&
                y < p.getY() + p.getHeight() &&
                y + height > p.getY();
    }

    public boolean intersects(double ex, double ey, double ew, double eh) {
        return x < ex + ew &&
                x + width > ex &&
                y < ey + eh &&
                y + height > ey;
    }
}