module org.example.platformergame {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.platformergame to javafx.fxml;
    exports org.example.platformergame;
}