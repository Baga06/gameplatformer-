module org.example.platformergame {
    requires javafx.controls;
    requires javafx.fxml;

    requires java.sql;
    requires org.postgresql.jdbc;

    opens org.example.platformergame to javafx.fxml;
    exports org.example.platformergame;
}
